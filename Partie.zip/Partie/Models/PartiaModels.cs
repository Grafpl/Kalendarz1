using System;
using System.Collections.Generic;
using System.ComponentModel;

namespace Kalendarz1.Partie.Models
{
    public class PartiaModel : INotifyPropertyChanged
    {
        public event PropertyChangedEventHandler PropertyChanged;
        protected void OnPropertyChanged(string name) =>
            PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(name));

        // Identyfikacja
        public string GUID { get; set; }
        public string DirID { get; set; }
        public string Partia { get; set; }
        public string CreateData { get; set; }
        public string CreateGodzina { get; set; }
        public string ArticleID { get; set; }

        // Status
        public int IsClose { get; set; }
        public string CloseData { get; set; }
        public string CloseGodzina { get; set; }
        public string CreateOperator { get; set; }
        public string CloseOperator { get; set; }

        // Dostawca
        public string CustomerID { get; set; }
        public string CustomerName { get; set; }

        // Operatorzy (nazwy)
        public string OtworzylNazwa { get; set; }
        public string ZamknalNazwa { get; set; }

        // Skup (FarmerCalc)
        public int SztDekl { get; set; }
        public decimal NettoSkup { get; set; }
        public int Padle { get; set; }
        public decimal CenaSkup { get; set; }

        // Wazenia - sumy
        public decimal WydanoKg { get; set; }
        public int WydanoSzt { get; set; }
        public decimal PrzyjetoKg { get; set; }
        public int PrzyjetoSzt { get; set; }

        // QC
        public decimal? KlasaBProc { get; set; }
        public decimal? PrzekarmienieKg { get; set; }
        public decimal? TempRampa { get; set; }
        public int? SkrzydlaOcena { get; set; }
        public int? NogiOcena { get; set; }
        public int? OparzeniaOcena { get; set; }
        public bool MaTemperatury { get; set; }
        public bool MaWady { get; set; }
        public int IloscZdjec { get; set; }

        // Computed
        public decimal NaStanieKg => WydanoKg - PrzyjetoKg;

        public decimal? WydajnoscProc =>
            NettoSkup > 0 ? Math.Round(WydanoKg / NettoSkup * 100, 1) : (decimal?)null;

        public string StatusText => IsClose == 1 ? "Zamknieta" : "Otwarta";

        public string QCBadge
        {
            get
            {
                if (MaTemperatury && MaWady) return "OK";
                if (MaTemperatury || MaWady) return "Czesciowe";
                return "Brak";
            }
        }

        public string ZamkniecieInfo =>
            IsClose == 1 ? $"{CloseData} {CloseGodzina}" : "";
    }

    public class WazenieModel
    {
        public string GUID { get; set; }
        public string ArticleID { get; set; }
        public string ArticleName { get; set; }
        public string JM { get; set; }
        public decimal ActWeight { get; set; }
        public int Quantity { get; set; }
        public decimal Weight { get; set; }
        public decimal Tara { get; set; }
        public string Data { get; set; }
        public string Godzina { get; set; }
        public string Wagowy { get; set; }
        public string Direction { get; set; }
        public string TruckID { get; set; }
        public string P1 { get; set; }
        public string P2 { get; set; }
        public bool IsStorno => ActWeight < 0;
        public string Zrodlo { get; set; } // "Out1A", "In0E" etc
    }

    public class ProduktPartiiModel
    {
        public string ArticleID { get; set; }
        public string ArticleName { get; set; }
        public string JM { get; set; }
        public decimal WydanoDodatnie { get; set; }
        public decimal StornoUjemne { get; set; }
        public decimal NettoKg { get; set; }
        public int SztDodatnie { get; set; }
        public int IleWazen { get; set; }
        public decimal ProcentUdzialu { get; set; }
    }

    public class QCDataModel
    {
        // Temperatury
        public List<TemperaturaModel> Temperatury { get; set; } = new();

        // Wady
        public int? SkrzydlaOcena { get; set; }
        public int? NogiOcena { get; set; }
        public int? OparzeniaOcena { get; set; }

        // Podsumowanie
        public decimal? KlasaBProc { get; set; }
        public decimal? PrzekarmienieKg { get; set; }
        public string Notatka { get; set; }

        // Zdjecia
        public List<ZdjecieModel> Zdjecia { get; set; } = new();
    }

    public class TemperaturaModel
    {
        public string Miejsce { get; set; }
        public decimal? Proba1 { get; set; }
        public decimal? Proba2 { get; set; }
        public decimal? Proba3 { get; set; }
        public decimal? Proba4 { get; set; }
        public decimal? Srednia { get; set; }
        public string Wykonal { get; set; }
    }

    public class ZdjecieModel
    {
        public string SciezkaPliku { get; set; }
        public string Opis { get; set; }
        public string WadaTyp { get; set; }
        public string Wykonal { get; set; }
    }

    public class SkupDataModel
    {
        public int FarmerCalcID { get; set; }
        public DateTime? CalcDate { get; set; }
        public string CustomerName { get; set; }
        public string CustomerID { get; set; }
        public string KierowcaNazwa { get; set; }
        public string CarID { get; set; }
        public string TrailerID { get; set; }
        public decimal BruttoWeight { get; set; }
        public decimal EmptyWeight { get; set; }
        public decimal NettoWeight { get; set; }
        public int DeclI1 { get; set; }
        public int DeclI2 { get; set; }
        public decimal Price { get; set; }
        public DateTime? Wyjazd { get; set; }
        public DateTime? Zaladunek { get; set; }
        public DateTime? Przyjazd { get; set; }
        public int StartKM { get; set; }
        public int StopKM { get; set; }

        public decimal WartoscNetto => NettoWeight * Price;
        public int KmTrasy => StopKM > StartKM ? StopKM - StartKM : 0;
    }

    public class HaccpModel
    {
        public string ZDzialu { get; set; }
        public string Artykul { get; set; }
        public string PartiaZrodlowa { get; set; }
        public string NaDzial { get; set; }
        public string ArtykulDocelowy { get; set; }
        public string PartiaDocelowa { get; set; }
        public decimal SumaKg { get; set; }
        public string MinDate { get; set; }
        public string MaxDate { get; set; }
    }

    public class TimelineEvent
    {
        public string EventTime { get; set; }
        public string EventType { get; set; }
        public string Description { get; set; }

        public string Icon => EventType switch
        {
            "OPEN" => "\U0001F7E2",      // green circle
            "CLOSE" => "\U0001F534",     // red circle
            "WEIGHT" => "\u2696",        // scales
            "TEMP" => "\U0001F321",      // thermometer
            "QC" => "\U0001F50D",        // magnifier
            "PHOTO" => "\U0001F4F7",     // camera
            "TRANSPORT" => "\U0001F69A", // truck
            _ => "\u2022"                // bullet
        };
    }

    public class PartieStatsModel
    {
        public int LiczbaPartii { get; set; }
        public int Otwartych { get; set; }
        public int Zamknietych { get; set; }
        public int DzisPartii { get; set; }
        public decimal DzisKg { get; set; }
        public decimal SrWydajnosc { get; set; }
        public decimal SrKlasaB { get; set; }
        public decimal SrTempRampa { get; set; }
    }

    public class DostawcaComboItem
    {
        public string ID { get; set; }
        public string Name { get; set; }
        public string Display => $"{ID} - {Name}";
    }
}

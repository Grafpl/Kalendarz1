using System;
using System.Windows;
using Kalendarz1.Partie.Models;
using Kalendarz1.Partie.Services;

namespace Kalendarz1.Partie.Windows
{
    public partial class ZamknijPartieDialog : Window
    {
        private readonly PartiaService _service;
        private readonly PartiaModel _partia;

        public ZamknijPartieDialog(PartiaModel partia)
        {
            InitializeComponent();
            _service = new PartiaService();
            _partia = partia;

            PopulateData();
        }

        private void PopulateData()
        {
            txtHeader.Text = $"ZAMKNIECIE PARTII {_partia.Partia}";
            txtSubHeader.Text = $"Dzial: {_partia.DirID}";
            txtDostawca.Text = $"{_partia.CustomerName} ({_partia.CustomerID})";
            txtDataOtwarcia.Text = $"{_partia.CreateData} {_partia.CreateGodzina}";
            txtOtworzyl.Text = _partia.OtworzylNazwa;

            txtWydano.Text = $"{_partia.WydanoKg:N1} kg ({_partia.WydanoSzt} szt)";
            txtPrzyjeto.Text = $"{_partia.PrzyjetoKg:N1} kg ({_partia.PrzyjetoSzt} szt)";
            txtNaStanie.Text = $"{_partia.NaStanieKg:N1} kg";
            txtWydajnosc.Text = _partia.WydajnoscProc.HasValue
                ? $"{_partia.WydajnoscProc:N1}%"
                : "- (brak danych skupu)";

            // QC
            txtQCTemp.Text = _partia.MaTemperatury
                ? $"Temperatury: Wypelnione (rampa: {_partia.TempRampa:N1} C)"
                : "Temperatury: BRAK";
            txtQCWady.Text = _partia.MaWady
                ? $"Wady: Skrz:{_partia.SkrzydlaOcena} Nogi:{_partia.NogiOcena} Opar:{_partia.OparzeniaOcena}"
                : "Wady: BRAK";
            txtQCKlasaB.Text = _partia.KlasaBProc.HasValue
                ? $"Klasa B: {_partia.KlasaBProc:N1}%"
                : "Klasa B: -";
            txtQCZdjecia.Text = $"Zdjecia: {_partia.IloscZdjec} szt.";

            // Warnings
            if (_partia.NaStanieKg > 10)
            {
                borderWarning.Visibility = Visibility.Visible;
                txtWarning.Text = $"Na stanie zostalo {_partia.NaStanieKg:N1} kg produktu! Czy na pewno chcesz zamknac?";
            }
            else if (!_partia.MaTemperatury || !_partia.MaWady)
            {
                borderWarning.Visibility = Visibility.Visible;
                txtWarning.Text = "Kontrola jakosci niekompletna! Brakuje " +
                    (!_partia.MaTemperatury ? "temperatur" : "") +
                    (!_partia.MaTemperatury && !_partia.MaWady ? " i " : "") +
                    (!_partia.MaWady ? "oceny wad" : "");
            }
        }

        private async void BtnZamknij_Click(object sender, RoutedEventArgs e)
        {
            BtnZamknij.IsEnabled = false;
            try
            {
                bool ok = await _service.ClosePartiaAsync(
                    _partia.Partia, App.UserID, txtKomentarz.Text?.Trim());

                if (ok)
                {
                    DialogResult = true;
                    Close();
                }
                else
                {
                    MessageBox.Show("Nie udalo sie zamknac partii. Moze juz jest zamknieta.",
                        "Informacja", MessageBoxButton.OK, MessageBoxImage.Warning);
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Blad zamykania partii:\n{ex.Message}", "Blad",
                    MessageBoxButton.OK, MessageBoxImage.Error);
            }
            finally
            {
                BtnZamknij.IsEnabled = true;
            }
        }

        private void BtnCancel_Click(object sender, RoutedEventArgs e)
        {
            DialogResult = false;
            Close();
        }
    }
}

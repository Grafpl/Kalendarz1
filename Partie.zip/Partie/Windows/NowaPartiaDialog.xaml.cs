using System;
using System.Windows;
using System.Windows.Controls;
using Kalendarz1.Partie.Models;
using Kalendarz1.Partie.Services;

namespace Kalendarz1.Partie.Windows
{
    public partial class NowaPartiaDialog : Window
    {
        private readonly PartiaService _service;

        public string CreatedPartia { get; private set; }

        public NowaPartiaDialog()
        {
            InitializeComponent();
            _service = new PartiaService();

            txtOtwarcie.Text = $"Otwarcie: {DateTime.Now:yyyy-MM-dd HH:mm}  |  Operator: {App.UserID ?? "Admin"}";
            txtInfo.Text = $"Data: {DateTime.Now:yyyy-MM-dd}";

            Loaded += async (s, e) =>
            {
                try
                {
                    var dostawcy = await _service.GetDostawcyAsync();
                    cmbDostawca.ItemsSource = dostawcy;
                }
                catch (Exception ex)
                {
                    MessageBox.Show($"Blad ladowania dostawcow:\n{ex.Message}", "Blad",
                        MessageBoxButton.OK, MessageBoxImage.Error);
                }
            };
        }

        private async void BtnUtworzPartie_Click(object sender, RoutedEventArgs e)
        {
            // Validation
            if (cmbDostawca.SelectedItem is not DostawcaComboItem dostawca)
            {
                MessageBox.Show("Wybierz dostawce.", "Wymagane pole",
                    MessageBoxButton.OK, MessageBoxImage.Warning);
                return;
            }

            var dzialItem = cmbDzial.SelectedItem as ComboBoxItem;
            string dirId = dzialItem?.Tag?.ToString() ?? "1A";

            BtnUtworzPartie.IsEnabled = false;
            try
            {
                CreatedPartia = await _service.CreatePartiaAsync(
                    dirId, dostawca.ID, dostawca.Name, null, App.UserID);

                MessageBox.Show($"Utworzono partie: {CreatedPartia}", "Sukces",
                    MessageBoxButton.OK, MessageBoxImage.Information);

                DialogResult = true;
                Close();
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Blad tworzenia partii:\n{ex.Message}", "Blad",
                    MessageBoxButton.OK, MessageBoxImage.Error);
            }
            finally
            {
                BtnUtworzPartie.IsEnabled = true;
            }
        }

        private void BtnCancel_Click(object sender, RoutedEventArgs e)
        {
            DialogResult = false;
            Close();
        }
    }
}

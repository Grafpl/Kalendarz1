using System;
using System.Collections.Generic;
using System.Threading.Tasks;
using Microsoft.Data.SqlClient;
using Kalendarz1.Partie.Models;

namespace Kalendarz1.Partie.Services
{
    public class PartiaService
    {
        private readonly string _connectionString;

        public PartiaService(string connectionString = null)
        {
            _connectionString = connectionString ??
                "Server=192.168.0.109;Database=LibraNet;User Id=pronova;Password=pronova;TrustServerCertificate=True";
        }

        // ═══════════════════════════════════════════════════════════════
        // LISTA PARTII (master grid)
        // ═══════════════════════════════════════════════════════════════

        public async Task<List<PartiaModel>> GetPartieAsync(string dataOd, string dataDo,
            string dzialFilter = null, int? statusFilter = null, string szukaj = null)
        {
            var partie = new List<PartiaModel>();

            string query = @"
SELECT
    lp.GUID, lp.DIR_ID, lp.Partia, lp.CreateData, lp.CreateGodzina,
    lp.IsClose, lp.CloseData, lp.CloseGodzina,
    lp.CreateOperator, lp.CloseOperator, lp.ArticleID,
    pd.CustomerID, pd.CustomerName,
    op_create.Name AS OtworzylNazwa,
    op_close.Name AS ZamknalNazwa,
    fc.DeclI1 AS SztDekl, fc.NettoWeight AS NettoSkup,
    fc.DeclI2 AS Padle, fc.Price AS CenaSkup,
    w_out.WydanoKg, w_out.WydanoSzt,
    w_in.PrzyjetoKg, w_in.PrzyjetoSzt,
    qcp.KlasaB_Proc, qcp.Przekarmienie_Kg,
    qct_rampa.Srednia AS TempRampa,
    qcw.Skrzydla_Ocena, qcw.Nogi_Ocena, qcw.Oparzenia_Ocena,
    CASE WHEN qct_rampa.Srednia IS NOT NULL THEN 1 ELSE 0 END AS MaTemperatury,
    CASE WHEN qcw.Skrzydla_Ocena IS NOT NULL THEN 1 ELSE 0 END AS MaWady,
    (SELECT COUNT(*) FROM Zdjecia z WHERE z.PartiaId = lp.Partia) AS IloscZdjec
FROM listapartii lp
LEFT JOIN PartiaDostawca pd ON lp.Partia = pd.Partia
LEFT JOIN operators op_create ON lp.CreateOperator = op_create.ID
LEFT JOIN operators op_close ON lp.CloseOperator = op_close.ID
LEFT JOIN (
    SELECT Partia, DeclI1, DeclI2, NettoWeight, Price,
           ROW_NUMBER() OVER (PARTITION BY Partia ORDER BY ID DESC) AS rn
    FROM FarmerCalc WHERE Deleted = 0 OR Deleted IS NULL
) fc ON fc.Partia = lp.Partia AND fc.rn = 1
LEFT JOIN (
    SELECT P1 AS Partia, SUM(ActWeight) AS WydanoKg, SUM(Quantity) AS WydanoSzt
    FROM Out1A WHERE ActWeight IS NOT NULL
    GROUP BY P1
) w_out ON w_out.Partia = lp.Partia
LEFT JOIN (
    SELECT P1 AS Partia, SUM(ActWeight) AS PrzyjetoKg, SUM(Quantity) AS PrzyjetoSzt
    FROM In0E WHERE ActWeight IS NOT NULL
    GROUP BY P1
) w_in ON w_in.Partia = lp.Partia
LEFT JOIN vw_QC_Podsum qcp ON qcp.PartiaId = lp.Partia
LEFT JOIN (
    SELECT PartiaId, Srednia,
           ROW_NUMBER() OVER (PARTITION BY PartiaId ORDER BY ID DESC) AS rn
    FROM TemperaturyMiejsca WHERE LOWER(Miejsce) = 'rampa'
) qct_rampa ON qct_rampa.PartiaId = lp.Partia AND qct_rampa.rn = 1
LEFT JOIN vw_QC_WadySkale qcw ON qcw.PartiaId = lp.Partia
WHERE lp.CreateData >= @DataOd AND lp.CreateData <= @DataDo";

            if (!string.IsNullOrEmpty(dzialFilter))
                query += " AND lp.DIR_ID = @Dzial";
            if (statusFilter.HasValue)
                query += " AND ISNULL(lp.IsClose, 0) = @Status";
            if (!string.IsNullOrEmpty(szukaj))
                query += " AND (lp.Partia LIKE @Szukaj OR pd.CustomerName LIKE @Szukaj OR pd.CustomerID LIKE @Szukaj)";

            query += " ORDER BY lp.CreateData DESC, lp.CreateGodzina DESC";

            using (var conn = new SqlConnection(_connectionString))
            {
                await conn.OpenAsync();
                using (var cmd = new SqlCommand(query, conn))
                {
                    cmd.CommandTimeout = 60;
                    cmd.Parameters.AddWithValue("@DataOd", dataOd);
                    cmd.Parameters.AddWithValue("@DataDo", dataDo);
                    if (!string.IsNullOrEmpty(dzialFilter))
                        cmd.Parameters.AddWithValue("@Dzial", dzialFilter);
                    if (statusFilter.HasValue)
                        cmd.Parameters.AddWithValue("@Status", statusFilter.Value);
                    if (!string.IsNullOrEmpty(szukaj))
                        cmd.Parameters.AddWithValue("@Szukaj", $"%{szukaj}%");

                    using (var reader = await cmd.ExecuteReaderAsync())
                    {
                        while (await reader.ReadAsync())
                        {
                            partie.Add(new PartiaModel
                            {
                                GUID = GetStringSafe(reader, "GUID"),
                                DirID = GetStringSafe(reader, "DIR_ID"),
                                Partia = GetStringSafe(reader, "Partia"),
                                CreateData = GetStringSafe(reader, "CreateData"),
                                CreateGodzina = GetStringSafe(reader, "CreateGodzina"),
                                IsClose = GetIntSafe(reader, "IsClose"),
                                CloseData = GetStringSafe(reader, "CloseData"),
                                CloseGodzina = GetStringSafe(reader, "CloseGodzina"),
                                CreateOperator = GetStringSafe(reader, "CreateOperator"),
                                CloseOperator = GetStringSafe(reader, "CloseOperator"),
                                ArticleID = GetStringSafe(reader, "ArticleID"),
                                CustomerID = GetStringSafe(reader, "CustomerID"),
                                CustomerName = GetStringSafe(reader, "CustomerName"),
                                OtworzylNazwa = GetStringSafe(reader, "OtworzylNazwa"),
                                ZamknalNazwa = GetStringSafe(reader, "ZamknalNazwa"),
                                SztDekl = GetIntSafe(reader, "SztDekl"),
                                NettoSkup = GetDecimalSafe(reader, "NettoSkup"),
                                Padle = GetIntSafe(reader, "Padle"),
                                CenaSkup = GetDecimalSafe(reader, "CenaSkup"),
                                WydanoKg = GetDecimalSafe(reader, "WydanoKg"),
                                WydanoSzt = GetIntSafe(reader, "WydanoSzt"),
                                PrzyjetoKg = GetDecimalSafe(reader, "PrzyjetoKg"),
                                PrzyjetoSzt = GetIntSafe(reader, "PrzyjetoSzt"),
                                KlasaBProc = GetDecimalNullable(reader, "KlasaB_Proc"),
                                PrzekarmienieKg = GetDecimalNullable(reader, "Przekarmienie_Kg"),
                                TempRampa = GetDecimalNullable(reader, "TempRampa"),
                                SkrzydlaOcena = GetIntNullable(reader, "Skrzydla_Ocena"),
                                NogiOcena = GetIntNullable(reader, "Nogi_Ocena"),
                                OparzeniaOcena = GetIntNullable(reader, "Oparzenia_Ocena"),
                                MaTemperatury = GetIntSafe(reader, "MaTemperatury") == 1,
                                MaWady = GetIntSafe(reader, "MaWady") == 1,
                                IloscZdjec = GetIntSafe(reader, "IloscZdjec")
                            });
                        }
                    }
                }
            }
            return partie;
        }

        // ═══════════════════════════════════════════════════════════════
        // WAZENIA (detail tab)
        // ═══════════════════════════════════════════════════════════════

        public async Task<List<WazenieModel>> GetWazeniaAsync(string partia)
        {
            var lista = new List<WazenieModel>();
            string query = @"
SELECT GUID, ArticleID, ArticleName, JM, ActWeight, Quantity, Weight,
       ISNULL(Tara,0) AS Tara, Data, Godzina, Wagowy, Direction, P1, P2, 'Out1A' AS Zrodlo
FROM Out1A WHERE P1 = @Partia
UNION ALL
SELECT GUID, ArticleID, ArticleName, JM, ActWeight, Quantity, Weight,
       ISNULL(Tara,0) AS Tara, Data, Godzina, Wagowy, Direction, P1, P2, 'In0E' AS Zrodlo
FROM In0E WHERE P1 = @Partia
ORDER BY Data DESC, Godzina DESC";

            using (var conn = new SqlConnection(_connectionString))
            {
                await conn.OpenAsync();
                using (var cmd = new SqlCommand(query, conn))
                {
                    cmd.CommandTimeout = 30;
                    cmd.Parameters.AddWithValue("@Partia", partia);
                    using (var reader = await cmd.ExecuteReaderAsync())
                    {
                        while (await reader.ReadAsync())
                        {
                            lista.Add(new WazenieModel
                            {
                                GUID = GetStringSafe(reader, "GUID"),
                                ArticleID = GetStringSafe(reader, "ArticleID"),
                                ArticleName = GetStringSafe(reader, "ArticleName"),
                                JM = GetStringSafe(reader, "JM"),
                                ActWeight = GetDecimalSafe(reader, "ActWeight"),
                                Quantity = GetIntSafe(reader, "Quantity"),
                                Weight = GetDecimalSafe(reader, "Weight"),
                                Tara = GetDecimalSafe(reader, "Tara"),
                                Data = GetStringSafe(reader, "Data"),
                                Godzina = GetStringSafe(reader, "Godzina"),
                                Wagowy = GetStringSafe(reader, "Wagowy"),
                                Direction = GetStringSafe(reader, "Direction"),
                                P1 = GetStringSafe(reader, "P1"),
                                P2 = GetStringSafe(reader, "P2"),
                                Zrodlo = GetStringSafe(reader, "Zrodlo")
                            });
                        }
                    }
                }
            }
            return lista;
        }

        // ═══════════════════════════════════════════════════════════════
        // PRODUKTY (sumy per artykul)
        // ═══════════════════════════════════════════════════════════════

        public async Task<List<ProduktPartiiModel>> GetProduktyAsync(string partia)
        {
            var lista = new List<ProduktPartiiModel>();
            string query = @"
SELECT ArticleID, ArticleName, JM,
       SUM(CASE WHEN ActWeight > 0 THEN ActWeight ELSE 0 END) AS WydanoDodatnie,
       SUM(CASE WHEN ActWeight < 0 THEN ActWeight ELSE 0 END) AS StornoUjemne,
       SUM(ActWeight) AS NettoKg,
       SUM(CASE WHEN ActWeight > 0 THEN Quantity ELSE 0 END) AS SztDodatnie,
       COUNT(*) AS IleWazen
FROM Out1A WHERE P1 = @Partia AND ActWeight IS NOT NULL
GROUP BY ArticleID, ArticleName, JM
ORDER BY SUM(ActWeight) DESC";

            decimal totalKg = 0;
            using (var conn = new SqlConnection(_connectionString))
            {
                await conn.OpenAsync();
                using (var cmd = new SqlCommand(query, conn))
                {
                    cmd.Parameters.AddWithValue("@Partia", partia);
                    using (var reader = await cmd.ExecuteReaderAsync())
                    {
                        while (await reader.ReadAsync())
                        {
                            var p = new ProduktPartiiModel
                            {
                                ArticleID = GetStringSafe(reader, "ArticleID"),
                                ArticleName = GetStringSafe(reader, "ArticleName"),
                                JM = GetStringSafe(reader, "JM"),
                                WydanoDodatnie = GetDecimalSafe(reader, "WydanoDodatnie"),
                                StornoUjemne = GetDecimalSafe(reader, "StornoUjemne"),
                                NettoKg = GetDecimalSafe(reader, "NettoKg"),
                                SztDodatnie = GetIntSafe(reader, "SztDodatnie"),
                                IleWazen = GetIntSafe(reader, "IleWazen")
                            };
                            totalKg += p.NettoKg;
                            lista.Add(p);
                        }
                    }
                }
            }

            if (totalKg > 0)
            {
                foreach (var p in lista)
                    p.ProcentUdzialu = Math.Round(p.NettoKg / totalKg * 100, 1);
            }

            return lista;
        }

        // ═══════════════════════════════════════════════════════════════
        // QC DATA
        // ═══════════════════════════════════════════════════════════════

        public async Task<QCDataModel> GetQCDataAsync(string partia)
        {
            var qc = new QCDataModel();

            using (var conn = new SqlConnection(_connectionString))
            {
                await conn.OpenAsync();

                // Temperatury
                using (var cmd = new SqlCommand(
                    "SELECT Miejsce, Proba1, Proba2, Proba3, Proba4, Srednia, Wykonal FROM TemperaturyMiejsca WHERE PartiaId = @P ORDER BY ID", conn))
                {
                    cmd.Parameters.AddWithValue("@P", partia);
                    using (var reader = await cmd.ExecuteReaderAsync())
                    {
                        while (await reader.ReadAsync())
                        {
                            qc.Temperatury.Add(new TemperaturaModel
                            {
                                Miejsce = GetStringSafe(reader, "Miejsce"),
                                Proba1 = GetDecimalNullable(reader, "Proba1"),
                                Proba2 = GetDecimalNullable(reader, "Proba2"),
                                Proba3 = GetDecimalNullable(reader, "Proba3"),
                                Proba4 = GetDecimalNullable(reader, "Proba4"),
                                Srednia = GetDecimalNullable(reader, "Srednia"),
                                Wykonal = GetStringSafe(reader, "Wykonal")
                            });
                        }
                    }
                }

                // Wady (ostatni wpis)
                using (var cmd = new SqlCommand(
                    "SELECT TOP 1 Skrzydla_Ocena, Nogi_Ocena, Oparzenia_Ocena FROM WadyPartiiSkale WHERE PartiaId = @P ORDER BY ID DESC", conn))
                {
                    cmd.Parameters.AddWithValue("@P", partia);
                    using (var reader = await cmd.ExecuteReaderAsync())
                    {
                        if (await reader.ReadAsync())
                        {
                            qc.SkrzydlaOcena = GetIntNullable(reader, "Skrzydla_Ocena");
                            qc.NogiOcena = GetIntNullable(reader, "Nogi_Ocena");
                            qc.OparzeniaOcena = GetIntNullable(reader, "Oparzenia_Ocena");
                        }
                    }
                }

                // Podsumowanie
                using (var cmd = new SqlCommand(
                    "SELECT TOP 1 KlasaB_Proc, Przekarmienie_Kg, Notatka FROM PodsumaPartii WHERE PartiaId = @P ORDER BY ID DESC", conn))
                {
                    cmd.Parameters.AddWithValue("@P", partia);
                    using (var reader = await cmd.ExecuteReaderAsync())
                    {
                        if (await reader.ReadAsync())
                        {
                            qc.KlasaBProc = GetDecimalNullable(reader, "KlasaB_Proc");
                            qc.PrzekarmienieKg = GetDecimalNullable(reader, "Przekarmienie_Kg");
                            qc.Notatka = GetStringSafe(reader, "Notatka");
                        }
                    }
                }

                // Zdjecia
                using (var cmd = new SqlCommand(
                    "SELECT SciezkaPliku, Opis, WadaTyp, Wykonal FROM Zdjecia WHERE PartiaId = @P ORDER BY ID", conn))
                {
                    cmd.Parameters.AddWithValue("@P", partia);
                    using (var reader = await cmd.ExecuteReaderAsync())
                    {
                        while (await reader.ReadAsync())
                        {
                            qc.Zdjecia.Add(new ZdjecieModel
                            {
                                SciezkaPliku = GetStringSafe(reader, "SciezkaPliku"),
                                Opis = GetStringSafe(reader, "Opis"),
                                WadaTyp = GetStringSafe(reader, "WadaTyp"),
                                Wykonal = GetStringSafe(reader, "Wykonal")
                            });
                        }
                    }
                }
            }
            return qc;
        }

        // ═══════════════════════════════════════════════════════════════
        // SKUP (FarmerCalc)
        // ═══════════════════════════════════════════════════════════════

        public async Task<SkupDataModel> GetSkupDataAsync(string partia)
        {
            string query = @"
SELECT TOP 1
    fc.ID, fc.CalcDate,
    ISNULL(dos.ShortName, fc.CustomerRealGID) AS CustomerName,
    fc.CustomerRealGID AS CustomerID,
    ISNULL(d.Name, '') AS KierowcaNazwa,
    fc.CarID, fc.TrailerID,
    ISNULL(fc.FullWeight, 0) AS BruttoWeight,
    ISNULL(fc.EmptyWeight, 0) AS EmptyWeight,
    ISNULL(fc.NettoWeight, 0) AS NettoWeight,
    ISNULL(fc.DeclI1, 0) AS DeclI1,
    ISNULL(fc.DeclI2, 0) AS DeclI2,
    ISNULL(fc.Price, 0) AS Price,
    fc.Wyjazd, fc.Zaladunek, fc.Przyjazd,
    ISNULL(fc.StartKM, 0) AS StartKM,
    ISNULL(fc.StopKM, 0) AS StopKM
FROM FarmerCalc fc
LEFT JOIN Dostawcy dos ON fc.CustomerRealGID = dos.ID
LEFT JOIN Driver d ON fc.DriverGID = d.GID
WHERE fc.Partia = @Partia AND (fc.Deleted = 0 OR fc.Deleted IS NULL)
ORDER BY fc.ID DESC";

            using (var conn = new SqlConnection(_connectionString))
            {
                await conn.OpenAsync();
                using (var cmd = new SqlCommand(query, conn))
                {
                    cmd.Parameters.AddWithValue("@Partia", partia);
                    using (var reader = await cmd.ExecuteReaderAsync())
                    {
                        if (await reader.ReadAsync())
                        {
                            return new SkupDataModel
                            {
                                FarmerCalcID = GetIntSafe(reader, "ID"),
                                CalcDate = GetDateTimeNullable(reader, "CalcDate"),
                                CustomerName = GetStringSafe(reader, "CustomerName"),
                                CustomerID = GetStringSafe(reader, "CustomerID"),
                                KierowcaNazwa = GetStringSafe(reader, "KierowcaNazwa"),
                                CarID = GetStringSafe(reader, "CarID"),
                                TrailerID = GetStringSafe(reader, "TrailerID"),
                                BruttoWeight = GetDecimalSafe(reader, "BruttoWeight"),
                                EmptyWeight = GetDecimalSafe(reader, "EmptyWeight"),
                                NettoWeight = GetDecimalSafe(reader, "NettoWeight"),
                                DeclI1 = GetIntSafe(reader, "DeclI1"),
                                DeclI2 = GetIntSafe(reader, "DeclI2"),
                                Price = GetDecimalSafe(reader, "Price"),
                                Wyjazd = GetDateTimeNullable(reader, "Wyjazd"),
                                Zaladunek = GetDateTimeNullable(reader, "Zaladunek"),
                                Przyjazd = GetDateTimeNullable(reader, "Przyjazd"),
                                StartKM = GetIntSafe(reader, "StartKM"),
                                StopKM = GetIntSafe(reader, "StopKM")
                            };
                        }
                    }
                }
            }
            return null;
        }

        // ═══════════════════════════════════════════════════════════════
        // HACCP
        // ═══════════════════════════════════════════════════════════════

        public async Task<List<HaccpModel>> GetHaccpAsync(string partia)
        {
            var lista = new List<HaccpModel>();
            string query = @"
SELECT Dir_ID1 AS ZDzialu, ID1 AS Artykul, P1 AS PartiaZrodlowa,
       Dir_ID2 AS NaDzial, ID2 AS ArtykulDocelowy, P2 AS PartiaDocelowa,
       ISNULL(SumaKg, 0) AS SumaKg, minDate, maxDate
FROM Haccp
WHERE P1 = @Partia OR P2 = @Partia
ORDER BY minDate";

            using (var conn = new SqlConnection(_connectionString))
            {
                await conn.OpenAsync();
                using (var cmd = new SqlCommand(query, conn))
                {
                    cmd.Parameters.AddWithValue("@Partia", partia);
                    using (var reader = await cmd.ExecuteReaderAsync())
                    {
                        while (await reader.ReadAsync())
                        {
                            lista.Add(new HaccpModel
                            {
                                ZDzialu = GetStringSafe(reader, "ZDzialu"),
                                Artykul = GetStringSafe(reader, "Artykul"),
                                PartiaZrodlowa = GetStringSafe(reader, "PartiaZrodlowa"),
                                NaDzial = GetStringSafe(reader, "NaDzial"),
                                ArtykulDocelowy = GetStringSafe(reader, "ArtykulDocelowy"),
                                PartiaDocelowa = GetStringSafe(reader, "PartiaDocelowa"),
                                SumaKg = GetDecimalSafe(reader, "SumaKg"),
                                MinDate = GetStringSafe(reader, "minDate"),
                                MaxDate = GetStringSafe(reader, "maxDate")
                            });
                        }
                    }
                }
            }
            return lista;
        }

        // ═══════════════════════════════════════════════════════════════
        // TIMELINE
        // ═══════════════════════════════════════════════════════════════

        public async Task<List<TimelineEvent>> GetTimelineAsync(string partia)
        {
            var lista = new List<TimelineEvent>();
            string query = @"
SELECT EventTime, EventType, Description FROM (
    SELECT lp.CreateData + ' ' + lp.CreateGodzina AS EventTime,
           'OPEN' AS EventType,
           'Otwarcie partii ' + lp.Partia + ' przez ' + ISNULL(o.Name, lp.CreateOperator) AS Description
    FROM listapartii lp LEFT JOIN operators o ON lp.CreateOperator = o.ID
    WHERE lp.Partia = @Partia
    UNION ALL
    SELECT lp.CloseData + ' ' + lp.CloseGodzina,
           'CLOSE',
           'Zamkniecie partii przez ' + ISNULL(o.Name, lp.CloseOperator)
    FROM listapartii lp LEFT JOIN operators o ON lp.CloseOperator = o.ID
    WHERE lp.Partia = @Partia AND lp.IsClose = 1
    UNION ALL
    SELECT Data + ' ' + Godzina, 'WEIGHT',
           'Wazenie: ' + ArticleName + ' ' + CAST(ActWeight AS varchar) + ' kg (' + ISNULL(Wagowy,'') + ')'
    FROM Out1A WHERE P1 = @Partia
    UNION ALL
    SELECT Data + ' ' + Godzina, 'WEIGHT',
           'Przyjecie 0E: ' + ArticleName + ' ' + CAST(ActWeight AS varchar) + ' kg'
    FROM In0E WHERE P1 = @Partia
) events
WHERE EventTime IS NOT NULL
ORDER BY EventTime ASC";

            using (var conn = new SqlConnection(_connectionString))
            {
                await conn.OpenAsync();
                using (var cmd = new SqlCommand(query, conn))
                {
                    cmd.CommandTimeout = 30;
                    cmd.Parameters.AddWithValue("@Partia", partia);
                    using (var reader = await cmd.ExecuteReaderAsync())
                    {
                        while (await reader.ReadAsync())
                        {
                            lista.Add(new TimelineEvent
                            {
                                EventTime = GetStringSafe(reader, "EventTime"),
                                EventType = GetStringSafe(reader, "EventType"),
                                Description = GetStringSafe(reader, "Description")
                            });
                        }
                    }
                }
            }
            return lista;
        }

        // ═══════════════════════════════════════════════════════════════
        // STATYSTYKI (dolny panel)
        // ═══════════════════════════════════════════════════════════════

        public async Task<PartieStatsModel> GetStatsAsync(List<PartiaModel> partie)
        {
            var stats = new PartieStatsModel
            {
                LiczbaPartii = partie.Count,
                Otwartych = 0,
                Zamknietych = 0
            };

            string dzis = DateTime.Today.ToString("yyyy-MM-dd");
            decimal sumWyd = 0, cntWyd = 0;
            decimal sumKlB = 0, cntKlB = 0;
            decimal sumTemp = 0, cntTemp = 0;

            foreach (var p in partie)
            {
                if (p.IsClose == 1) stats.Zamknietych++;
                else stats.Otwartych++;

                if (p.CreateData == dzis)
                {
                    stats.DzisPartii++;
                    stats.DzisKg += p.NettoSkup;
                }

                if (p.WydajnoscProc.HasValue) { sumWyd += p.WydajnoscProc.Value; cntWyd++; }
                if (p.KlasaBProc.HasValue) { sumKlB += p.KlasaBProc.Value; cntKlB++; }
                if (p.TempRampa.HasValue) { sumTemp += p.TempRampa.Value; cntTemp++; }
            }

            stats.SrWydajnosc = cntWyd > 0 ? Math.Round(sumWyd / cntWyd, 1) : 0;
            stats.SrKlasaB = cntKlB > 0 ? Math.Round(sumKlB / cntKlB, 1) : 0;
            stats.SrTempRampa = cntTemp > 0 ? Math.Round(sumTemp / cntTemp, 1) : 0;

            return stats;
        }

        // ═══════════════════════════════════════════════════════════════
        // TWORZENIE PARTII
        // ═══════════════════════════════════════════════════════════════

        public async Task<string> CreatePartiaAsync(string dirId, string customerID, string customerName,
            string articleId, string operatorId)
        {
            string nrPartii = null;

            using (var conn = new SqlConnection(_connectionString))
            {
                await conn.OpenAsync();
                using (var tran = conn.BeginTransaction())
                {
                    try
                    {
                        // Generowanie numeru partii
                        var now = DateTime.Now;
                        int rok2 = now.Year % 100;
                        int dzienRoku = now.DayOfYear;
                        string dayKey = dzienRoku.ToString("D3");

                        using (var cmd = new SqlCommand(
                            "SELECT ISNULL(MAX(PartNo), 0) + 1 FROM partnumbers WHERE Day = @Day", conn, tran))
                        {
                            cmd.Parameters.AddWithValue("@Day", $"{rok2}{dayKey}");
                            var nextNo = Convert.ToInt32(await cmd.ExecuteScalarAsync());
                            nrPartii = $"{rok2}{dayKey}{nextNo:D3}";
                        }

                        // Wpis do partnumbers
                        using (var cmd = new SqlCommand(@"
INSERT INTO partnumbers (ServerID, TermID, ScaleType, Day, PartNo, CalcPartNo)
VALUES ('1', '1', '1', @Day, @PartNo, @CalcPartNo)", conn, tran))
                        {
                            cmd.Parameters.AddWithValue("@Day", $"{rok2}{dayKey}");
                            cmd.Parameters.AddWithValue("@PartNo",
                                Convert.ToInt32(nrPartii.Substring(5)));
                            cmd.Parameters.AddWithValue("@CalcPartNo", nrPartii);
                            await cmd.ExecuteNonQueryAsync();
                        }

                        string guid = Guid.NewGuid().ToString();
                        string dataStr = now.ToString("yyyy-MM-dd");
                        string godzinaStr = now.ToString("HH:mm:ss");

                        // INSERT listapartii
                        using (var cmd = new SqlCommand(@"
INSERT INTO listapartii (GUID, DIR_ID, Partia, ArticleID, CreateData, CreateGodzina, CreateOperator, IsClose)
VALUES (@GUID, @DirID, @Partia, @ArticleID, @Data, @Godz, @Operator, 0)", conn, tran))
                        {
                            cmd.Parameters.AddWithValue("@GUID", guid);
                            cmd.Parameters.AddWithValue("@DirID", dirId);
                            cmd.Parameters.AddWithValue("@Partia", nrPartii);
                            cmd.Parameters.AddWithValue("@ArticleID", (object)articleId ?? DBNull.Value);
                            cmd.Parameters.AddWithValue("@Data", dataStr);
                            cmd.Parameters.AddWithValue("@Godz", godzinaStr);
                            cmd.Parameters.AddWithValue("@Operator", (object)operatorId ?? DBNull.Value);
                            await cmd.ExecuteNonQueryAsync();
                        }

                        // INSERT PartiaDostawca
                        using (var cmd = new SqlCommand(@"
INSERT INTO PartiaDostawca (guid, Partia, CustomerID, CustomerName, CreateData, CreateGodzina, ModificationData, ModificationGodzina)
VALUES (@GUID, @Partia, @CustID, @CustName, @Data, @Godz, @Data, @Godz)", conn, tran))
                        {
                            cmd.Parameters.AddWithValue("@GUID", Guid.NewGuid().ToString());
                            cmd.Parameters.AddWithValue("@Partia", nrPartii);
                            cmd.Parameters.AddWithValue("@CustID", customerID);
                            cmd.Parameters.AddWithValue("@CustName", customerName ?? "");
                            cmd.Parameters.AddWithValue("@Data", dataStr);
                            cmd.Parameters.AddWithValue("@Godz", godzinaStr);
                            await cmd.ExecuteNonQueryAsync();
                        }

                        // Audit log
                        await InsertAuditLogAsync(conn, tran, nrPartii, "Otwarta",
                            $"Nowa partia {nrPartii}, dzial {dirId}, dostawca {customerName}",
                            operatorId, null);

                        tran.Commit();
                    }
                    catch
                    {
                        tran.Rollback();
                        throw;
                    }
                }
            }
            return nrPartii;
        }

        // ═══════════════════════════════════════════════════════════════
        // ZAMYKANIE PARTII
        // ═══════════════════════════════════════════════════════════════

        public async Task<bool> ClosePartiaAsync(string partia, string operatorId, string komentarz)
        {
            using (var conn = new SqlConnection(_connectionString))
            {
                await conn.OpenAsync();
                string dataStr = DateTime.Now.ToString("yyyy-MM-dd");
                string godzinaStr = DateTime.Now.ToString("HH:mm:ss");

                using (var cmd = new SqlCommand(@"
UPDATE listapartii SET
    IsClose = 1,
    CloseData = @Data, CloseGodzina = @Godz, CloseOperator = @Operator,
    ModificationData = @Data, ModificationGodzina = @Godz
WHERE Partia = @Partia AND (IsClose = 0 OR IsClose IS NULL)", conn))
                {
                    cmd.Parameters.AddWithValue("@Data", dataStr);
                    cmd.Parameters.AddWithValue("@Godz", godzinaStr);
                    cmd.Parameters.AddWithValue("@Operator", (object)operatorId ?? DBNull.Value);
                    cmd.Parameters.AddWithValue("@Partia", partia);
                    int rows = await cmd.ExecuteNonQueryAsync();

                    if (rows > 0)
                    {
                        await InsertAuditLogAsync(conn, null, partia, "Zamknieta",
                            string.IsNullOrEmpty(komentarz) ? "Zamkniecie partii" : komentarz,
                            operatorId, null);
                    }
                    return rows > 0;
                }
            }
        }

        // ═══════════════════════════════════════════════════════════════
        // PONOWNE OTWARCIE
        // ═══════════════════════════════════════════════════════════════

        public async Task<bool> ReopenPartiaAsync(string partia, string operatorId, string powod)
        {
            using (var conn = new SqlConnection(_connectionString))
            {
                await conn.OpenAsync();
                string dataStr = DateTime.Now.ToString("yyyy-MM-dd");
                string godzinaStr = DateTime.Now.ToString("HH:mm:ss");

                using (var cmd = new SqlCommand(@"
UPDATE listapartii SET
    IsClose = 0,
    CloseData = NULL, CloseGodzina = NULL, CloseOperator = NULL,
    ModificationData = @Data, ModificationGodzina = @Godz
WHERE Partia = @Partia AND IsClose = 1", conn))
                {
                    cmd.Parameters.AddWithValue("@Data", dataStr);
                    cmd.Parameters.AddWithValue("@Godz", godzinaStr);
                    cmd.Parameters.AddWithValue("@Partia", partia);
                    int rows = await cmd.ExecuteNonQueryAsync();

                    if (rows > 0)
                    {
                        await InsertAuditLogAsync(conn, null, partia, "PonownieOtwarta",
                            "Powod: " + (powod ?? ""), operatorId, null);
                    }
                    return rows > 0;
                }
            }
        }

        // ═══════════════════════════════════════════════════════════════
        // DOSTAWCY (combo)
        // ═══════════════════════════════════════════════════════════════

        public async Task<List<DostawcaComboItem>> GetDostawcyAsync()
        {
            var lista = new List<DostawcaComboItem>();
            using (var conn = new SqlConnection(_connectionString))
            {
                await conn.OpenAsync();
                using (var cmd = new SqlCommand(
                    "SELECT ID, ShortName FROM Dostawcy WHERE ISNULL(Halt, 0) = 0 ORDER BY ShortName", conn))
                {
                    using (var reader = await cmd.ExecuteReaderAsync())
                    {
                        while (await reader.ReadAsync())
                        {
                            lista.Add(new DostawcaComboItem
                            {
                                ID = GetStringSafe(reader, "ID"),
                                Name = GetStringSafe(reader, "ShortName")
                            });
                        }
                    }
                }
            }
            return lista;
        }

        // ═══════════════════════════════════════════════════════════════
        // HELPERS
        // ═══════════════════════════════════════════════════════════════

        private async Task InsertAuditLogAsync(SqlConnection conn, SqlTransaction tran,
            string partia, string akcja, string opis, string operatorId, string operatorNazwa)
        {
            using (var cmd = new SqlCommand(@"
INSERT INTO PartiaAuditLog (Partia, Akcja, Opis, OperatorID, OperatorNazwa)
VALUES (@Partia, @Akcja, @Opis, @OpID, @OpNazwa)", conn, tran))
            {
                cmd.Parameters.AddWithValue("@Partia", partia);
                cmd.Parameters.AddWithValue("@Akcja", akcja);
                cmd.Parameters.AddWithValue("@Opis", (object)opis ?? DBNull.Value);
                cmd.Parameters.AddWithValue("@OpID", (object)operatorId ?? DBNull.Value);
                cmd.Parameters.AddWithValue("@OpNazwa", (object)operatorNazwa ?? DBNull.Value);
                try { await cmd.ExecuteNonQueryAsync(); } catch { /* audit log failure should not break main operation */ }
            }
        }

        private static string GetStringSafe(SqlDataReader reader, string column)
        {
            int ordinal = reader.GetOrdinal(column);
            return reader.IsDBNull(ordinal) ? "" : reader.GetString(ordinal);
        }

        private static int GetIntSafe(SqlDataReader reader, string column)
        {
            int ordinal = reader.GetOrdinal(column);
            if (reader.IsDBNull(ordinal)) return 0;
            return Convert.ToInt32(reader.GetValue(ordinal));
        }

        private static int? GetIntNullable(SqlDataReader reader, string column)
        {
            int ordinal = reader.GetOrdinal(column);
            if (reader.IsDBNull(ordinal)) return null;
            return Convert.ToInt32(reader.GetValue(ordinal));
        }

        private static decimal GetDecimalSafe(SqlDataReader reader, string column)
        {
            int ordinal = reader.GetOrdinal(column);
            if (reader.IsDBNull(ordinal)) return 0;
            return Convert.ToDecimal(reader.GetValue(ordinal));
        }

        private static decimal? GetDecimalNullable(SqlDataReader reader, string column)
        {
            int ordinal = reader.GetOrdinal(column);
            if (reader.IsDBNull(ordinal)) return null;
            return Convert.ToDecimal(reader.GetValue(ordinal));
        }

        private static DateTime? GetDateTimeNullable(SqlDataReader reader, string column)
        {
            int ordinal = reader.GetOrdinal(column);
            return reader.IsDBNull(ordinal) ? null : reader.GetDateTime(ordinal);
        }
    }
}

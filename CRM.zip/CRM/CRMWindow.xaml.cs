using Kalendarz1.OfertaCenowa;
using Kalendarz1.CRM.Services;
using Microsoft.Data.SqlClient;
using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Data;
using System.Diagnostics;
using System.Linq;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Controls.Primitives;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Animation;
using System.Windows.Media.Imaging;

namespace Kalendarz1.CRM
{
    public partial class CRMWindow : Window
    {
        private readonly string connectionString = "Server=192.168.0.109;Database=LibraNet;User Id=pronova;Password=pronova;TrustServerCertificate=True";
        private string operatorID = "";
        private int aktualnyOdbiorcaID = 0;
        private DataTable dtKontakty;
        private bool isLoading = false;

        // Avatar cache: operator name → BitmapSource
        private readonly Dictionary<string, BitmapSource> _handlowiecAvatarCache = new();
        private readonly Dictionary<string, string> _handlowiecNameToId = new();

        public string UserID { get; set; }

        [System.Runtime.InteropServices.DllImport("gdi32.dll")]
        private static extern bool DeleteObject(IntPtr hObject);

        public CRMWindow()
        {
            InitializeComponent();
            WindowIconHelper.SetIcon(this);
            Loaded += CRMWindow_Loaded;
            dgKontakty.LoadingRow += DgKontakty_LoadingRow;
        }

        private void CRMWindow_Loaded(object sender, RoutedEventArgs e)
        {
            operatorID = UserID;
            if (operatorID != "11111")
            {
                if (btnManager != null) btnManager.Visibility = Visibility.Collapsed;
                if (btnAdmin != null) btnAdmin.Visibility = Visibility.Collapsed;
            }

            // Load and apply saved theme
            CRMThemeService.Load();
            if (CRMThemeService.CurrentTheme == CRMThemeMode.Light)
                ApplyCRMTheme(true);
            else
                UpdateThemeButton(false);

            // Załaduj logo firmy
            LoadCompanyLogo();

            // Załaduj avatar i nazwę zalogowanego użytkownika
            LoadCurrentUserInfo();

            InicjalizujFiltry();
            LoadHandlowiecAvatarMap();
            WczytajDane();
        }

        private static readonly string LogoSettingsPath = System.IO.Path.Combine(
            Environment.GetFolderPath(Environment.SpecialFolder.ApplicationData),
            "Kalendarz1", "crm_logo.txt");

        private void LoadCompanyLogo()
        {
            try
            {
                if (System.IO.File.Exists(LogoSettingsPath))
                {
                    string logoPath = System.IO.File.ReadAllText(LogoSettingsPath).Trim();
                    if (!string.IsNullOrEmpty(logoPath) && System.IO.File.Exists(logoPath))
                    {
                        var bitmap = new System.Windows.Media.Imaging.BitmapImage();
                        bitmap.BeginInit();
                        bitmap.UriSource = new Uri(logoPath);
                        bitmap.CacheOption = System.Windows.Media.Imaging.BitmapCacheOption.OnLoad;
                        bitmap.EndInit();
                        imgLogo.Source = bitmap;
                        txtLogoPlaceholder.Visibility = Visibility.Collapsed;

                        // Dostosuj rozmiar kontenera do proporcji obrazu
                        AdjustLogoContainerSize(bitmap.PixelWidth, bitmap.PixelHeight);
                    }
                }
            }
            catch
            {
                // Ignoruj błędy ładowania logo
            }
        }

        private void AdjustLogoContainerSize(int imgWidth, int imgHeight)
        {
            if (imgWidth <= 0 || imgHeight <= 0) return;

            double maxWidth = 280;
            double maxHeight = 80;
            double aspectRatio = (double)imgWidth / imgHeight;

            double targetWidth, targetHeight;

            // Oblicz rozmiar zachowując proporcje
            if (aspectRatio > maxWidth / maxHeight)
            {
                // Obraz jest szerszy - ogranicz szerokością
                targetWidth = maxWidth;
                targetHeight = maxWidth / aspectRatio;
            }
            else
            {
                // Obraz jest wyższy - ogranicz wysokością
                targetHeight = maxHeight;
                targetWidth = maxHeight * aspectRatio;
            }

            // Ustaw minimalne wymiary
            targetWidth = Math.Max(80, targetWidth);
            targetHeight = Math.Max(50, targetHeight);

            borderLogo.Width = targetWidth;
            borderLogo.Height = targetHeight;
        }

        private void SaveLogoPath(string path)
        {
            try
            {
                var dir = System.IO.Path.GetDirectoryName(LogoSettingsPath);
                if (!System.IO.Directory.Exists(dir))
                    System.IO.Directory.CreateDirectory(dir);
                System.IO.File.WriteAllText(LogoSettingsPath, path ?? "");
            }
            catch { }
        }

        private void LoadCurrentUserInfo()
        {
            try
            {
                // Pobierz nazwę użytkownika
                using (var conn = new SqlConnection(connectionString))
                {
                    conn.Open();
                    var cmd = new SqlCommand("SELECT Name FROM operators WHERE ID = @id", conn);
                    cmd.Parameters.AddWithValue("@id", operatorID);
                    var name = cmd.ExecuteScalar()?.ToString();
                    if (!string.IsNullOrEmpty(name) && txtUserName != null)
                        txtUserName.Text = name;
                }

                // Załaduj avatar - teraz 40px
                if (imgUserAvatar != null)
                {
                    System.Drawing.Image avatarImg = null;
                    if (UserAvatarManager.HasAvatar(operatorID))
                        avatarImg = UserAvatarManager.GetAvatarRounded(operatorID, 40);

                    if (avatarImg == null)
                    {
                        string userName = txtUserName?.Text ?? "U";
                        avatarImg = UserAvatarManager.GenerateDefaultAvatar(userName, operatorID, 40);
                    }

                    if (avatarImg != null)
                    {
                        using (avatarImg)
                        using (var bmp = new System.Drawing.Bitmap(avatarImg))
                        {
                            var hBitmap = bmp.GetHbitmap();
                            try
                            {
                                var source = System.Windows.Interop.Imaging.CreateBitmapSourceFromHBitmap(
                                    hBitmap, IntPtr.Zero, Int32Rect.Empty,
                                    BitmapSizeOptions.FromEmptyOptions());
                                source.Freeze();
                                imgUserAvatar.Source = source;
                            }
                            finally { DeleteObject(hBitmap); }
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                Debug.WriteLine($"LoadCurrentUserInfo error: {ex.Message}");
            }
        }

        #region Handlowiec Avatars

        private void LoadHandlowiecAvatarMap()
        {
            try
            {
                using var conn = new SqlConnection(connectionString);
                conn.Open();
                using var cmd = new SqlCommand("SELECT ID, Name FROM operators WHERE Name IS NOT NULL", conn);
                using var reader = cmd.ExecuteReader();
                while (reader.Read())
                {
                    string id = reader["ID"].ToString();
                    string name = reader["Name"]?.ToString()?.Trim() ?? "";
                    if (!string.IsNullOrEmpty(name) && !_handlowiecNameToId.ContainsKey(name))
                        _handlowiecNameToId[name] = id;
                }
            }
            catch { }
        }

        private BitmapSource GetHandlowiecAvatar(string name, string directId = null)
        {
            if (string.IsNullOrWhiteSpace(name)) return null;

            // Trim i normalizuj nazwę
            name = name.Trim();

            // Cache key oparty tylko na nazwie (nie na directId - bo bywa błędne)
            string cacheKey = name;
            if (_handlowiecAvatarCache.TryGetValue(cacheKey, out var cached))
                return cached;

            BitmapSource source = null;
            try
            {
                // Szukaj ID po nazwie w mapie
                string userId = _handlowiecNameToId.TryGetValue(name, out var id) ? id : name;

                System.Drawing.Image img = null;
                if (UserAvatarManager.HasAvatar(userId))
                    img = UserAvatarManager.GetAvatarRounded(userId, 28);
                if (img == null)
                    img = UserAvatarManager.GenerateDefaultAvatar(name, userId, 28);

                if (img != null)
                {
                    using (img)
                    using (var bmp = new System.Drawing.Bitmap(img))
                    {
                        var hBitmap = bmp.GetHbitmap();
                        try
                        {
                            source = System.Windows.Interop.Imaging.CreateBitmapSourceFromHBitmap(
                                hBitmap, IntPtr.Zero, Int32Rect.Empty,
                                BitmapSizeOptions.FromEmptyOptions());
                            source.Freeze();
                        }
                        finally { DeleteObject(hBitmap); }
                    }
                }
            }
            catch { }

            _handlowiecAvatarCache[cacheKey] = source;
            return source;
        }

        private void DgKontakty_LoadingRow(object sender, DataGridRowEventArgs e)
        {
            // Avatar jest teraz ładowany przez HandlowiecAvatarConverter w XAML
            // Nie potrzebujemy już Row_Loaded dla avatarów
        }

        private void Row_Loaded(object sender, RoutedEventArgs e)
        {
            // Avatar jest teraz ładowany przez HandlowiecAvatarConverter w XAML binding
            // Ta metoda jest zachowana dla kompatybilności, ale nie wykonuje już żadnych operacji
        }

        private void LoadRankingAvatars()
        {
            try
            {
                if (listaRanking == null || listaRanking.Items.Count == 0) return;

                for (int i = 0; i < listaRanking.Items.Count; i++)
                {
                    var container = listaRanking.ItemContainerGenerator.ContainerFromIndex(i) as FrameworkElement;
                    if (container == null) continue;

                    var img = FindVisualChild<System.Windows.Controls.Image>(container);
                    if (img == null || img.Source != null) continue;

                    if (listaRanking.Items[i] is DataRowView drv)
                    {
                        string operatorName = drv["Operator"]?.ToString();
                        string operatorId = drv["OperatorID"]?.ToString();
                        if (string.IsNullOrWhiteSpace(operatorName)) continue;

                        BitmapSource avatar = null;
                        try
                        {
                            string userId = !string.IsNullOrEmpty(operatorId) ? operatorId : operatorName;
                            System.Drawing.Image avatarImg = null;
                            if (UserAvatarManager.HasAvatar(userId))
                                avatarImg = UserAvatarManager.GetAvatarRounded(userId, 30);
                            if (avatarImg == null)
                                avatarImg = UserAvatarManager.GenerateDefaultAvatar(operatorName, userId, 30);

                            if (avatarImg != null)
                            {
                                using (avatarImg)
                                using (var bmp = new System.Drawing.Bitmap(avatarImg))
                                {
                                    var hBitmap = bmp.GetHbitmap();
                                    try
                                    {
                                        avatar = System.Windows.Interop.Imaging.CreateBitmapSourceFromHBitmap(
                                            hBitmap, IntPtr.Zero, Int32Rect.Empty,
                                            BitmapSizeOptions.FromEmptyOptions());
                                        avatar.Freeze();
                                    }
                                    finally { DeleteObject(hBitmap); }
                                }
                            }
                        }
                        catch { }

                        if (avatar != null)
                            img.Source = avatar;
                    }
                }
            }
            catch { }
        }

        private void LoadNotatkiAvatars()
        {
            try
            {
                if (listaNotatek == null || listaNotatek.Items.Count == 0) return;

                for (int i = 0; i < listaNotatek.Items.Count; i++)
                {
                    var container = listaNotatek.ItemContainerGenerator.ContainerFromIndex(i) as FrameworkElement;
                    if (container == null) continue;

                    var img = FindVisualChild<System.Windows.Controls.Image>(container);
                    if (img == null || img.Source != null) continue;

                    if (listaNotatek.Items[i] is NotatkaCRM notatka)
                    {
                        string operatorName = notatka.Operator;
                        if (string.IsNullOrWhiteSpace(operatorName)) continue;

                        var avatar = GetHandlowiecAvatar(operatorName);
                        if (avatar != null)
                            img.Source = avatar;
                    }
                }
            }
            catch { }
        }

        private static T FindVisualChild<T>(DependencyObject obj) where T : DependencyObject
        {
            for (int i = 0; i < VisualTreeHelper.GetChildrenCount(obj); i++)
            {
                var child = VisualTreeHelper.GetChild(obj, i);
                if (child is T t) return t;
                var result = FindVisualChild<T>(child);
                if (result != null) return result;
            }
            return null;
        }

        #endregion

        #region Ładowanie Danych
        private void InicjalizujFiltry()
        {
            cmbStatus.Items.Clear();
            cmbStatus.Items.Add(new ComboBoxItem { Content = "Wszystkie statusy", IsSelected = true });
            cmbStatus.Items.Add(new ComboBoxItem { Content = "Do zadzwonienia" });
            cmbStatus.Items.Add(new ComboBoxItem { Content = "Próba kontaktu" });
            cmbStatus.Items.Add(new ComboBoxItem { Content = "Nawiązano kontakt" });
            cmbStatus.Items.Add(new ComboBoxItem { Content = "Zgoda na dalszy kontakt" });
            cmbStatus.Items.Add(new ComboBoxItem { Content = "Do wysłania oferta" });
            cmbStatus.Items.Add(new ComboBoxItem { Content = "Nie zainteresowany" });

            cmbWojewodztwo.Items.Clear(); cmbWojewodztwo.Items.Add(new ComboBoxItem { Content = "Wszystkie woj.", IsSelected = true });
            cmbBranza.Items.Clear(); cmbBranza.Items.Add(new ComboBoxItem { Content = "Wszystkie branże", IsSelected = true });

            cmbHandlowiec.Items.Clear();
            cmbHandlowiec.Items.Add(new ComboBoxItem { Content = "Wszyscy", IsSelected = true });
        }

        private void WczytajDane()
        {
            WczytajDane(zachowajFiltry: false);
        }

        private void WczytajDane(bool zachowajFiltry)
        {
            isLoading = true;
            if (loadingOverlay != null) loadingOverlay.Visibility = Visibility.Visible;

            // Zapisz stan filtrów przed odświeżeniem
            int savedStatusIndex = zachowajFiltry ? cmbStatus.SelectedIndex : 0;
            int savedWojIndex = zachowajFiltry ? cmbWojewodztwo.SelectedIndex : 0;
            int savedBranzaIndex = zachowajFiltry ? cmbBranza.SelectedIndex : 0;
            int savedHandlowiecIndex = zachowajFiltry ? cmbHandlowiec.SelectedIndex : 0;
            string savedBranzaText = zachowajFiltry && cmbBranza.SelectedItem is ComboBoxItem bi ? bi.Content?.ToString() : null;
            string savedHandlowiecText = zachowajFiltry && cmbHandlowiec.SelectedItem is ComboBoxItem hi ? hi.Content?.ToString() : null;
            int savedOdbiorcaID = zachowajFiltry ? aktualnyOdbiorcaID : 0;

            try
            {
                WczytajKontakty();
                WczytajKPI();
                WczytajRanking();

                if (!zachowajFiltry)
                {
                    InicjalizujFiltry();
                    WypelnijFiltryDynamiczne();
                }

                ObliczTargetDnia();

                // Przywróć filtry
                if (zachowajFiltry)
                {
                    if (savedStatusIndex >= 0 && savedStatusIndex < cmbStatus.Items.Count)
                        cmbStatus.SelectedIndex = savedStatusIndex;

                    if (savedWojIndex >= 0 && savedWojIndex < cmbWojewodztwo.Items.Count)
                        cmbWojewodztwo.SelectedIndex = savedWojIndex;

                    // Przywróć branżę po tekście (bo lista może się zmienić)
                    if (!string.IsNullOrEmpty(savedBranzaText))
                    {
                        for (int i = 0; i < cmbBranza.Items.Count; i++)
                        {
                            if (cmbBranza.Items[i] is ComboBoxItem item && item.Content?.ToString() == savedBranzaText)
                            {
                                cmbBranza.SelectedIndex = i;
                                break;
                            }
                        }
                    }

                    // Przywróć handlowca po tekście
                    if (!string.IsNullOrEmpty(savedHandlowiecText))
                    {
                        for (int i = 0; i < cmbHandlowiec.Items.Count; i++)
                        {
                            if (cmbHandlowiec.Items[i] is ComboBoxItem item && item.Content?.ToString() == savedHandlowiecText)
                            {
                                cmbHandlowiec.SelectedIndex = i;
                                break;
                            }
                        }
                    }

                    // Przywróć zaznaczony wiersz
                    if (savedOdbiorcaID > 0 && dgKontakty.ItemsSource != null)
                    {
                        Filtruj();
                        foreach (DataRowView row in dgKontakty.Items)
                        {
                            if (row["ID"] != DBNull.Value && (int)row["ID"] == savedOdbiorcaID)
                            {
                                dgKontakty.SelectedItem = row;
                                dgKontakty.ScrollIntoView(row);
                                break;
                            }
                        }
                    }
                }
            }
            catch (Exception ex) { MessageBox.Show($"Błąd: {ex.Message}"); }
            finally
            {
                isLoading = false;
                if (loadingOverlay != null) loadingOverlay.Visibility = Visibility.Collapsed;
            }
        }

        /// <summary>
        /// Aktualizuje status kontaktu lokalnie w DataTable bez przeładowywania całej listy.
        /// Dzięki temu widok nie jest resetowany i użytkownik zostaje na tej samej pozycji.
        /// </summary>
        private void AktualizujStatusLokalnie(int kontaktId, string nowyStatus)
        {
            if (dtKontakty == null) return;

            // Znajdź wiersz w DataTable
            foreach (DataRow row in dtKontakty.Rows)
            {
                if (row["ID"] != DBNull.Value && (int)row["ID"] == kontaktId)
                {
                    // Aktualizuj status
                    row["Status"] = nowyStatus;
                    // Aktualizuj datę ostatniej zmiany
                    row["OstatniaZmiana"] = DateTime.Now;
                    // Aktualizuj ostatniego handlowca - pobierz nazwę operatora
                    try
                    {
                        using (var conn = new SqlConnection(connectionString))
                        {
                            conn.Open();
                            var cmd = new SqlCommand("SELECT Name FROM operators WHERE ID = @id", conn);
                            cmd.Parameters.AddWithValue("@id", operatorID);
                            var result = cmd.ExecuteScalar();
                            if (result != null)
                            {
                                row["OstatniHandlowiec"] = result.ToString();
                                row["OstatniHandlowiecID"] = operatorID;
                            }
                        }
                    }
                    catch { }
                    // Odśwież flagę zaniedbania
                    row["CzyZaniedbany"] = false;
                    break;
                }
            }

            // Odśwież tylko liczniki celów (bez przeładowywania listy)
            ObliczTargetDnia();

            // Odśwież widok DataGrid żeby pokazać zmiany
            dgKontakty.Items.Refresh();
        }

        /// <summary>
        /// Aktualizuje notatkę kontaktu lokalnie bez przeładowywania całej listy.
        /// </summary>
        private void AktualizujNotatkeLokalnie(int kontaktId, string nowaNotatka)
        {
            if (dtKontakty == null) return;

            foreach (DataRow row in dtKontakty.Rows)
            {
                if (row["ID"] != DBNull.Value && (int)row["ID"] == kontaktId)
                {
                    row["OstatniNotatka"] = nowaNotatka;
                    row["OstatniaZmiana"] = DateTime.Now;
                    try
                    {
                        using (var conn = new SqlConnection(connectionString))
                        {
                            conn.Open();
                            var cmd = new SqlCommand("SELECT Name FROM operators WHERE ID = @id", conn);
                            cmd.Parameters.AddWithValue("@id", operatorID);
                            var result = cmd.ExecuteScalar();
                            if (result != null)
                            {
                                row["OstatniHandlowiec"] = result.ToString();
                                row["OstatniHandlowiecID"] = operatorID;
                            }
                        }
                    }
                    catch { }
                    row["CzyZaniedbany"] = false;
                    break;
                }
            }

            ObliczTargetDnia();
            dgKontakty.Items.Refresh();
        }

        /// <summary>
        /// Aktualizuje datę następnego kontaktu lokalnie bez przeładowywania całej listy.
        /// </summary>
        private void AktualizujDateLokalnie(int kontaktId, DateTime nowaData)
        {
            if (dtKontakty == null) return;

            foreach (DataRow row in dtKontakty.Rows)
            {
                if (row["ID"] != DBNull.Value && (int)row["ID"] == kontaktId)
                {
                    row["DataNastepnegoKontaktu"] = nowaData;
                    break;
                }
            }
            dgKontakty.Items.Refresh();
        }

        // Baza firmy - współrzędne do obliczania dystansu
        private const double BazaLat = 51.907335;
        private const double BazaLng = 19.678605;

        private void WczytajKontakty()
        {
            _handlowiecAvatarCache.Clear();
            HandlowiecAvatarConverter.ClearCache(); // Wyczyść cache konwertera
            bool tylkoMoje = chkTylkoMoje?.IsChecked == true;

            using (var conn = new SqlConnection(connectionString))
            {
                conn.Open();

                // Upewnij się że tabela WlascicieleOdbiorcow ma kolumnę Priorytet
                using (var cmdCheck = new SqlCommand(@"
                    IF NOT EXISTS (SELECT * FROM sys.columns WHERE object_id = OBJECT_ID('WlascicieleOdbiorcow') AND name = 'Priorytet')
                    ALTER TABLE WlascicieleOdbiorcow ADD Priorytet BIT DEFAULT 0", conn))
                {
                    cmdCheck.ExecuteNonQuery();
                }

                // Różne zapytanie w zależności od filtra "Tylko moi"
                string whereClause = tylkoMoje
                    ? "WHERE w.OperatorID = @OperatorID AND ISNULL(o.Status, '') NOT IN ('Poprosił o usunięcie', 'Błędny rekord (do raportu)')"
                    : "WHERE (w.OperatorID = @OperatorID OR w.OperatorID IS NULL) AND ISNULL(o.Status, '') NOT IN ('Poprosił o usunięcie', 'Błędny rekord (do raportu)')";

                var cmd = new SqlCommand($@"
                    SELECT o.ID, o.Nazwa as NAZWA, o.KOD, o.MIASTO, o.ULICA, o.Telefon_K as TELEFON_K, o.Email,
                        o.Wojewodztwo, o.PKD_Opis, o.Tagi, ISNULL(o.Status, 'Do zadzwonienia') as Status, o.DataNastepnegoKontaktu,
                        (SELECT TOP 1 Data FROM (
                            SELECT DataZmiany as Data FROM HistoriaZmianCRM WHERE IDOdbiorcy = o.ID
                            UNION ALL
                            SELECT DataUtworzenia FROM NotatkiCRM WHERE IDOdbiorcy = o.ID
                        ) daty ORDER BY Data DESC) as OstatniaZmiana,
                        (SELECT TOP 1 ISNULL(op.Name, x.Operator) FROM (
                            SELECT CAST(KtoDodal AS VARCHAR(15)) as Operator, DataUtworzenia as Data FROM NotatkiCRM WHERE IDOdbiorcy = o.ID
                            UNION ALL
                            SELECT KtoWykonal, DataZmiany FROM HistoriaZmianCRM WHERE IDOdbiorcy = o.ID
                        ) x LEFT JOIN operators op ON
                            (TRY_CAST(x.Operator AS INT) IS NOT NULL AND op.ID = x.Operator)
                            OR (TRY_CAST(x.Operator AS INT) IS NULL AND op.Name = x.Operator)
                        ORDER BY x.Data DESC) as OstatniHandlowiec,
                        (SELECT TOP 1 op2.ID FROM (
                            SELECT CAST(KtoDodal AS VARCHAR(15)) as Operator, DataUtworzenia as Data FROM NotatkiCRM WHERE IDOdbiorcy = o.ID
                            UNION ALL
                            SELECT KtoWykonal, DataZmiany FROM HistoriaZmianCRM WHERE IDOdbiorcy = o.ID
                        ) x LEFT JOIN operators op2 ON
                            (TRY_CAST(x.Operator AS INT) IS NOT NULL AND op2.ID = x.Operator)
                            OR (TRY_CAST(x.Operator AS INT) IS NULL AND op2.Name = x.Operator)
                        ORDER BY x.Data DESC) as OstatniHandlowiecID,
                        (SELECT TOP 1 Tresc FROM NotatkiCRM WHERE IDOdbiorcy = o.ID ORDER BY DataUtworzenia DESC) as OstatniNotatka,
                        kp.Latitude, kp.Longitude,
                        CASE WHEN EXISTS (SELECT 1 FROM CRM_PKDPriority pkp WHERE pkp.PKDCode = o.PKD_Opis) THEN 1 ELSE 0 END as IsPriorityPKD
                    FROM OdbiorcyCRM o
                    LEFT JOIN WlascicieleOdbiorcow w ON o.ID = w.IDOdbiorcy
                    LEFT JOIN KodyPocztowe kp ON o.KOD = kp.Kod
                    {whereClause}
                    ORDER BY
                        CASE WHEN EXISTS (SELECT 1 FROM CRM_PKDPriority pkp WHERE pkp.PKDCode = o.PKD_Opis) THEN 0 ELSE 1 END,
                        ISNULL(w.Priorytet, 0) DESC,
                        CASE WHEN o.DataNastepnegoKontaktu IS NULL THEN 1 ELSE 0 END,
                        o.DataNastepnegoKontaktu ASC", conn);

                cmd.Parameters.AddWithValue("@OperatorID", operatorID);
                var adapter = new SqlDataAdapter(cmd);
                dtKontakty = new DataTable();
                adapter.Fill(dtKontakty);

                if (!dtKontakty.Columns.Contains("CzyZaniedbany")) dtKontakty.Columns.Add("CzyZaniedbany", typeof(bool));
                if (!dtKontakty.Columns.Contains("MaTagi")) dtKontakty.Columns.Add("MaTagi", typeof(bool));
                if (!dtKontakty.Columns.Contains("Km")) dtKontakty.Columns.Add("Km", typeof(string));

                foreach (DataRow r in dtKontakty.Rows)
                {
                    if (r["OstatniaZmiana"] != DBNull.Value)
                    {
                        var data = (DateTime)r["OstatniaZmiana"];
                        if ((DateTime.Now - data).TotalDays > 30) r["CzyZaniedbany"] = true;
                        else r["CzyZaniedbany"] = false;
                    }
                    else r["CzyZaniedbany"] = false;
                    r["MaTagi"] = !string.IsNullOrEmpty(r["Tagi"]?.ToString());

                    // Wojewodztwo z malej litery
                    if (r["Wojewodztwo"] != DBNull.Value && !string.IsNullOrEmpty(r["Wojewodztwo"].ToString()))
                        r["Wojewodztwo"] = r["Wojewodztwo"].ToString().ToLower();

                    // Oblicz dystans
                    if (r["Latitude"] != DBNull.Value && r["Longitude"] != DBNull.Value)
                    {
                        double lat = Convert.ToDouble(r["Latitude"]);
                        double lng = Convert.ToDouble(r["Longitude"]);
                        double km = ObliczDystans(BazaLat, BazaLng, lat, lng);
                        r["Km"] = km.ToString("0");
                    }
                    else r["Km"] = "-";
                }
                dgKontakty.ItemsSource = dtKontakty.DefaultView;
                if (txtLiczbaWynikow != null) txtLiczbaWynikow.Text = $"{dtKontakty.Rows.Count} klientów";
            }
        }

        private double ObliczDystans(double lat1, double lon1, double lat2, double lon2)
        {
            var R = 6371; // Promień ziemi w km
            var dLat = (lat2 - lat1) * Math.PI / 180;
            var dLon = (lon2 - lon1) * Math.PI / 180;
            var a = Math.Sin(dLat / 2) * Math.Sin(dLat / 2) +
                    Math.Cos(lat1 * Math.PI / 180) * Math.Cos(lat2 * Math.PI / 180) *
                    Math.Sin(dLon / 2) * Math.Sin(dLon / 2);
            var c = 2 * Math.Atan2(Math.Sqrt(a), Math.Sqrt(1 - a));
            return R * c;
        }

        private void WczytajKPI()
        {
            // KPI cards removed from UI - method kept for compatibility
        }

        private void ObliczTargetDnia()
        {
            try
            {
                using (var conn = new SqlConnection(connectionString))
                {
                    conn.Open();

                    // Pobierz cele z tabeli CallReminderConfig (jak w oknie Przypomnienia)
                    int celDzienny = 15;
                    int celTygodniowy = 120;
                    var cmdTarget = new SqlCommand(@"
                        SELECT TOP 1 DailyCallTarget, WeeklyCallTarget FROM CallReminderConfig
                        WHERE UserID = @op AND IsEnabled = 1", conn);
                    cmdTarget.Parameters.AddWithValue("@op", operatorID);
                    using (var reader = cmdTarget.ExecuteReader())
                    {
                        if (reader.Read())
                        {
                            if (reader["DailyCallTarget"] != DBNull.Value)
                                celDzienny = Convert.ToInt32(reader["DailyCallTarget"]);
                            if (reader["WeeklyCallTarget"] != DBNull.Value)
                                celTygodniowy = Convert.ToInt32(reader["WeeklyCallTarget"]);
                        }
                    }

                    // Wykonane dziś i w tym tygodniu - używamy tabeli CallReminderContacts (jak w oknie Przypomnienia)
                    var cmdCalls = new SqlCommand(@"
                        SELECT
                            ISNULL((SELECT COUNT(DISTINCT crc.ContactID)
                                    FROM CallReminderContacts crc
                                    INNER JOIN CallReminderLog crl ON crc.ReminderLogID = crl.ID
                                    WHERE crl.UserID = @op
                                    AND crl.ReminderTime >= CAST(CAST(GETDATE() AS DATE) AS DATETIME)
                                    AND (crc.WasCalled = 1 OR crc.StatusChanged = 1 OR crc.NoteAdded = 1)), 0) as DayCalls,
                            ISNULL((SELECT COUNT(DISTINCT crc.ContactID)
                                    FROM CallReminderContacts crc
                                    INNER JOIN CallReminderLog crl ON crc.ReminderLogID = crl.ID
                                    WHERE crl.UserID = @op
                                    AND crl.ReminderTime >= DATEADD(DAY,
                                        -((DATEPART(WEEKDAY, GETDATE()) + @@DATEFIRST - 2) % 7),
                                        CAST(CAST(GETDATE() AS DATE) AS DATETIME))
                                    AND (crc.WasCalled = 1 OR crc.StatusChanged = 1 OR crc.NoteAdded = 1)), 0) as WeekCalls", conn);
                    cmdCalls.Parameters.AddWithValue("@op", operatorID);

                    int wykonaneDzis = 0;
                    int wykonaneTydzien = 0;
                    using (var reader = cmdCalls.ExecuteReader())
                    {
                        if (reader.Read())
                        {
                            wykonaneDzis = Convert.ToInt32(reader["DayCalls"]);
                            wykonaneTydzien = Convert.ToInt32(reader["WeekCalls"]);
                        }
                    }

                    // Aktualizuj nowe UI - cele dzienne
                    if (txtCelDziennyWykonane != null) txtCelDziennyWykonane.Text = wykonaneDzis.ToString();
                    if (txtCelDziennyCel != null) txtCelDziennyCel.Text = celDzienny.ToString();

                    // Aktualizuj nowe UI - cele tygodniowe
                    if (txtCelTygodniowyWykonane != null) txtCelTygodniowyWykonane.Text = wykonaneTydzien.ToString();
                    if (txtCelTygodniowyCel != null) txtCelTygodniowyCel.Text = celTygodniowy.ToString();

                    // Kolorowanie kart celów - zielone jeśli osiągnięte, czerwone jeśli nie
                    bool celDziennyOsiagniety = wykonaneDzis >= celDzienny;
                    bool celTygodniowyOsiagniety = wykonaneTydzien >= celTygodniowy;

                    if (borderCelDzienny != null)
                    {
                        borderCelDzienny.Background = new SolidColorBrush(
                            celDziennyOsiagniety
                                ? System.Windows.Media.Color.FromRgb(20, 83, 45)   // Zielony #14532D
                                : System.Windows.Media.Color.FromRgb(127, 29, 29)  // Czerwony #7F1D1D
                        );
                    }
                    if (borderCelTygodniowy != null)
                    {
                        borderCelTygodniowy.Background = new SolidColorBrush(
                            celTygodniowyOsiagniety
                                ? System.Windows.Media.Color.FromRgb(20, 83, 45)   // Zielony #14532D
                                : System.Windows.Media.Color.FromRgb(127, 29, 29)  // Czerwony #7F1D1D
                        );
                    }

                    // Stare UI (ukryte, ale zachowane dla kompatybilności)
                    if (txtTargetLabel != null) txtTargetLabel.Text = $"CEL DNIA ({celDzienny})";
                    if (txtTargetInfo != null) txtTargetInfo.Text = $"{wykonaneDzis}/{celDzienny}";
                    if (pbTarget != null)
                    {
                        pbTarget.Maximum = celDzienny;
                        pbTarget.Value = wykonaneDzis;
                    }
                }
            }
            catch { }
        }

        private string FormatujTelefon(string telefon)
        {
            if (string.IsNullOrWhiteSpace(telefon)) return "";

            // Usuń wszystkie znaki niebędące cyframi
            var digits = new string(telefon.Where(char.IsDigit).ToArray());

            if (digits.Length == 9)
            {
                // Format: XXX XXX XXX
                return $"{digits.Substring(0, 3)} {digits.Substring(3, 3)} {digits.Substring(6, 3)}";
            }
            else if (digits.Length == 11 && digits.StartsWith("48"))
            {
                // Format: +48 XXX XXX XXX
                return $"+48 {digits.Substring(2, 3)} {digits.Substring(5, 3)} {digits.Substring(8, 3)}";
            }
            else if (digits.Length >= 7)
            {
                // Format ogólny z separatorami co 3 cyfry
                var result = "";
                for (int i = 0; i < digits.Length; i++)
                {
                    if (i > 0 && i % 3 == 0) result += " ";
                    result += digits[i];
                }
                return result;
            }

            return telefon;
        }

        private void WczytajRanking(bool tygodniowy = false)
        {
            try
            {
                using (var conn = new SqlConnection(connectionString))
                {
                    conn.Open();

                    // Ładuj ranking dzienny
                    var dtDzienny = LoadRankingData(conn, false);
                    if (listaRankingDzienny != null)
                        listaRankingDzienny.ItemsSource = dtDzienny.DefaultView;

                    // Ładuj ranking tygodniowy
                    var dtTygodniowy = LoadRankingData(conn, true);
                    if (listaRankingTygodniowy != null)
                        listaRankingTygodniowy.ItemsSource = dtTygodniowy.DefaultView;

                    // Stara lista dla kompatybilności
                    if (listaRanking != null)
                        listaRanking.ItemsSource = (tygodniowy ? dtTygodniowy : dtDzienny).DefaultView;

                    // Aktualizuj pozycję użytkownika w nagłówku
                    AktualizujPozycjeUzytkownika(dtDzienny, dtTygodniowy);
                }
            }
            catch { }
        }

        private void AktualizujPozycjeUzytkownika(DataTable dtDzienny, DataTable dtTygodniowy)
        {
            try
            {
                // Znajdź pozycję w rankingu dziennym
                int pozDzienna = 0;
                for (int i = 0; i < dtDzienny.Rows.Count; i++)
                {
                    if (dtDzienny.Rows[i]["OperatorID"]?.ToString() == operatorID)
                    {
                        pozDzienna = i + 1;
                        break;
                    }
                }

                // Znajdź pozycję w rankingu tygodniowym
                int pozTygodniowa = 0;
                for (int i = 0; i < dtTygodniowy.Rows.Count; i++)
                {
                    if (dtTygodniowy.Rows[i]["OperatorID"]?.ToString() == operatorID)
                    {
                        pozTygodniowa = i + 1;
                        break;
                    }
                }

                // Aktualizuj UI - kolorowe medale (złoto, srebro, brąz)
                if (txtPozycjaDzienna != null)
                {
                    txtPozycjaDzienna.Text = pozDzienna switch
                    {
                        1 => "1",
                        2 => "2",
                        3 => "3",
                        > 0 => $"#{pozDzienna}",
                        _ => ""
                    };
                    txtPozycjaDzienna.Foreground = new SolidColorBrush(pozDzienna switch
                    {
                        1 => System.Windows.Media.Color.FromRgb(255, 215, 0),   // Gold
                        2 => System.Windows.Media.Color.FromRgb(192, 192, 192), // Silver
                        3 => System.Windows.Media.Color.FromRgb(205, 127, 50),  // Bronze
                        _ => System.Windows.Media.Color.FromRgb(148, 163, 184)  // Gray
                    });
                    txtPozycjaDzienna.FontWeight = pozDzienna <= 3 ? FontWeights.Bold : FontWeights.Normal;
                }

                if (txtPozycjaTygodniowa != null)
                {
                    txtPozycjaTygodniowa.Text = pozTygodniowa switch
                    {
                        1 => "1",
                        2 => "2",
                        3 => "3",
                        > 0 => $"#{pozTygodniowa}",
                        _ => ""
                    };
                    txtPozycjaTygodniowa.Foreground = new SolidColorBrush(pozTygodniowa switch
                    {
                        1 => System.Windows.Media.Color.FromRgb(255, 215, 0),   // Gold
                        2 => System.Windows.Media.Color.FromRgb(192, 192, 192), // Silver
                        3 => System.Windows.Media.Color.FromRgb(205, 127, 50),  // Bronze
                        _ => System.Windows.Media.Color.FromRgb(148, 163, 184)  // Gray
                    });
                    txtPozycjaTygodniowa.FontWeight = pozTygodniowa <= 3 ? FontWeights.Bold : FontWeights.Normal;
                }
            }
            catch { }
        }

        private DataTable LoadRankingData(SqlConnection conn, bool tygodniowy)
        {
            // Używamy tej samej logiki co w oknie Przypomnienia - z tabeli CallReminderConfig i CallReminderContacts
            string dateFilter = tygodniowy
                ? @"AND crl.ReminderTime >= DATEADD(DAY,
                        -((DATEPART(WEEKDAY, GETDATE()) + @@DATEFIRST - 2) % 7),
                        CAST(CAST(GETDATE() AS DATE) AS DATETIME))"
                : "AND crl.ReminderTime >= CAST(CAST(GETDATE() AS DATE) AS DATETIME)";

            string targetColumn = tygodniowy ? "c.WeeklyCallTarget" : "c.DailyCallTarget";

            var cmd = new SqlCommand($@"
                SELECT
                    ROW_NUMBER() OVER (ORDER BY
                        ISNULL((SELECT COUNT(DISTINCT crc.ContactID)
                                FROM CallReminderLog crl
                                INNER JOIN CallReminderContacts crc ON crc.ReminderLogID = crl.ID
                                WHERE crl.UserID = c.UserID
                                {dateFilter}
                                AND (crc.WasCalled = 1 OR crc.StatusChanged = 1 OR crc.NoteAdded = 1)), 0) DESC,
                        o.Name) as Pozycja,
                    ISNULL(o.Name, 'ID: ' + c.UserID) as Operator,
                    c.UserID as OperatorID,
                    ISNULL((SELECT COUNT(DISTINCT crc.ContactID)
                            FROM CallReminderLog crl
                            INNER JOIN CallReminderContacts crc ON crc.ReminderLogID = crl.ID
                            WHERE crl.UserID = c.UserID
                            {dateFilter}
                            AND (crc.WasCalled = 1 OR crc.StatusChanged = 1 OR crc.NoteAdded = 1)), 0) as Wykonane,
                    ISNULL({targetColumn}, {(tygodniowy ? "120" : "15")}) as Cel,
                    CASE WHEN ISNULL({targetColumn}, {(tygodniowy ? "120" : "15")}) > 0
                         THEN CAST(ROUND(
                            CAST(ISNULL((SELECT COUNT(DISTINCT crc.ContactID)
                                FROM CallReminderLog crl
                                INNER JOIN CallReminderContacts crc ON crc.ReminderLogID = crl.ID
                                WHERE crl.UserID = c.UserID
                                {dateFilter}
                                AND (crc.WasCalled = 1 OR crc.StatusChanged = 1 OR crc.NoteAdded = 1)), 0) AS FLOAT)
                            / ISNULL({targetColumn}, {(tygodniowy ? "120" : "15")}) * 100, 0) AS INT)
                         ELSE 0 END as Procent
                FROM CallReminderConfig c
                LEFT JOIN operators o ON o.ID = c.UserID
                WHERE c.IsEnabled = 1
                ORDER BY Wykonane DESC, Operator", conn);

            var adapter = new SqlDataAdapter(cmd);
            var dt = new DataTable();
            adapter.Fill(dt);

            // Dodaj kolumny Medal i ProcentTekst
            dt.Columns.Add("Medal", typeof(string));
            dt.Columns.Add("ProcentTekst", typeof(string));

            int pozycja = 1;
            foreach (DataRow row in dt.Rows)
            {
                int procent = row["Procent"] != DBNull.Value ? Convert.ToInt32(row["Procent"]) : 0;
                row["ProcentTekst"] = $"{procent}%";

                // Medale dla top 3
                row["Medal"] = pozycja switch
                {
                    1 => "🥇",
                    2 => "🥈",
                    3 => "🥉",
                    _ => $"{pozycja}."
                };
                pozycja++;
            }

            return dt;
        }

        private void RbOkresRankingu_Checked(object sender, RoutedEventArgs e)
        {
            if (rbDzienny == null || rbTygodniowy == null) return;
            WczytajRanking(rbTygodniowy.IsChecked == true);
        }

        private void ListaRanking_MouseDoubleClick(object sender, MouseButtonEventArgs e)
        {
            if (listaRanking.SelectedItem is DataRowView row)
            {
                bool tygodniowy = rbTygodniowy?.IsChecked == true;
                var okno = new HistoriaHandlowcaWindow(connectionString, row, tygodniowy);
                okno.Show();
            }
        }

        private void WypelnijFiltryDynamiczne()
        {
            if (dtKontakty == null) return;
            var woj = dtKontakty.AsEnumerable().Select(r => r["Wojewodztwo"].ToString()).Where(x => !string.IsNullOrEmpty(x)).Distinct().OrderBy(x => x);
            foreach (var w in woj) cmbWojewodztwo.Items.Add(new ComboBoxItem { Content = w });

            // Load priority PKDs from database
            var priorityPKDs = new HashSet<string>();
            try
            {
                using var conn = new SqlConnection(connectionString);
                conn.Open();
                var cmd = new SqlCommand("SELECT PKDCode FROM CRM_PKDPriority ORDER BY SortOrder", conn);
                using var reader = cmd.ExecuteReader();
                while (reader.Read())
                {
                    priorityPKDs.Add(reader.GetString(0));
                }
            }
            catch { }

            // Get all unique branches
            var branze = dtKontakty.AsEnumerable()
                .Select(r => r["PKD_Opis"].ToString())
                .Where(x => !string.IsNullOrEmpty(x))
                .Distinct()
                .ToList();

            // Add priority PKDs first (in red)
            var priorityBranze = branze.Where(b => priorityPKDs.Contains(b)).OrderBy(b => b).ToList();
            foreach (var b in priorityBranze)
            {
                cmbBranza.Items.Add(new ComboBoxItem
                {
                    Content = b,
                    Foreground = new SolidColorBrush(System.Windows.Media.Color.FromRgb(239, 68, 68)), // #EF4444
                    FontWeight = FontWeights.SemiBold
                });
            }

            // Add separator if there are priority items
            if (priorityBranze.Count > 0)
            {
                cmbBranza.Items.Add(new ComboBoxItem
                {
                    Content = "─────────────",
                    IsEnabled = false,
                    Foreground = new SolidColorBrush(System.Windows.Media.Color.FromRgb(100, 116, 139))
                });
            }

            // Add remaining PKDs (not in priority list)
            var normalBranze = branze.Where(b => !priorityPKDs.Contains(b)).OrderBy(b => b);
            foreach (var b in normalBranze)
            {
                cmbBranza.Items.Add(new ComboBoxItem { Content = b });
            }

            // Wypełnij listę handlowców którzy mieli aktywność
            var handlowcy = dtKontakty.AsEnumerable()
                .Select(r => r["OstatniHandlowiec"]?.ToString())
                .Where(x => !string.IsNullOrEmpty(x))
                .Distinct()
                .OrderBy(x => x);
            foreach (var h in handlowcy) cmbHandlowiec.Items.Add(new ComboBoxItem { Content = h });
        }
        #endregion

        #region Interakcje
        private void DgKontakty_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            // Anuluj edycję notatki przy zmianie wiersza
            if (edytowanaNotatkaId > 0)
            {
                edytowanaNotatkaId = 0;
                txtNowaNotatka.Text = "";
                btnDodajNotatke.Content = "Dodaj";
            }

            if (dgKontakty.SelectedItem is DataRowView row)
            {
                aktualnyOdbiorcaID = Convert.ToInt32(row["ID"]);

                // HEADER
                if (txtHeaderKlient != null) txtHeaderKlient.Text = row["NAZWA"].ToString();
                if (txtHeaderTelefon != null) txtHeaderTelefon.Text = FormatujTelefon(row["TELEFON_K"].ToString());
                if (txtHeaderMiasto != null) txtHeaderMiasto.Text = row["MIASTO"].ToString();

                // PANEL BOCZNY - AKTYWNY ODBIORCA
                if (txtPanelKlientNazwa != null) txtPanelKlientNazwa.Text = row["NAZWA"].ToString();
                if (txtPanelKlientMiasto != null) txtPanelKlientMiasto.Text = row["MIASTO"].ToString();
                if (txtPanelKlientTelefon != null) txtPanelKlientTelefon.Text = FormatujTelefon(row["TELEFON_K"].ToString());

                // PLANOWANY KONTAKT W HEADERZE
                if (row["DataNastepnegoKontaktu"] != DBNull.Value && txtKlientNastepnyKontakt != null)
                {
                    DateTime data = (DateTime)row["DataNastepnegoKontaktu"];
                    txtKlientNastepnyKontakt.Text = data.ToString("dd.MM");
                    if (panelNastepnyKontakt != null)
                    {
                        if (data < DateTime.Today) panelNastepnyKontakt.Background = (Brush)new BrushConverter().ConvertFrom("#FEE2E2");
                        else if (data == DateTime.Today) panelNastepnyKontakt.Background = (Brush)new BrushConverter().ConvertFrom("#DBEAFE");
                        else panelNastepnyKontakt.Background = (Brush)new BrushConverter().ConvertFrom("#DCFCE7");
                    }
                }
                else if (txtKlientNastepnyKontakt != null)
                {
                    txtKlientNastepnyKontakt.Text = "Brak";
                    if (panelNastepnyKontakt != null) panelNastepnyKontakt.Background = (Brush)new BrushConverter().ConvertFrom("#F3F4F6");
                }
                WczytajNotatki(aktualnyOdbiorcaID);
            }
        }

        private void WczytajNotatki(int id)
        {
            if (listaNotatek == null) return;
            using (var conn = new SqlConnection(connectionString))
            {
                conn.Open();
                // Łączymy notatki i zmiany statusów
                var cmd = new SqlCommand(@"
                    SELECT Id, Tresc, DataUtworzenia, Operator, Typ, CzyNotatka FROM (
                        SELECT n.ID as Id, n.Tresc, n.DataUtworzenia, ISNULL(o.Name, n.KtoDodal) as Operator,
                               '📝' as Typ, CAST(1 AS BIT) as CzyNotatka
                        FROM NotatkiCRM n
                        LEFT JOIN operators o ON o.ID = CAST(n.KtoDodal AS VARCHAR(15))
                        WHERE n.IDOdbiorcy = @id
                        UNION ALL
                        SELECT 0 as Id, CONCAT('Status: ', h.WartoscNowa) as Tresc, h.DataZmiany as DataUtworzenia,
                               ISNULL(o.Name, h.KtoWykonal) as Operator, '🔄' as Typ, CAST(0 AS BIT) as CzyNotatka
                        FROM HistoriaZmianCRM h
                        LEFT JOIN operators o ON o.ID = h.KtoWykonal
                        WHERE h.IDOdbiorcy = @id AND h.TypZmiany = 'Zmiana statusu'
                    ) AS Historia
                    ORDER BY DataUtworzenia DESC", conn);
                cmd.Parameters.AddWithValue("@id", id);
                var adapter = new SqlDataAdapter(cmd);
                var dt = new DataTable(); adapter.Fill(dt);
                var list = new ObservableCollection<NotatkaCRM>();
                foreach (DataRow r in dt.Rows) list.Add(new NotatkaCRM {
                    Id = Convert.ToInt32(r["Id"]),
                    Tresc = r["Tresc"].ToString(),
                    DataUtworzenia = (DateTime)r["DataUtworzenia"],
                    Operator = r["Operator"].ToString(),
                    Typ = r["Typ"].ToString(),
                    CzyNotatka = Convert.ToBoolean(r["CzyNotatka"])
                });
                listaNotatek.ItemsSource = list;
                // Load avatars after layout
                Dispatcher.BeginInvoke(System.Windows.Threading.DispatcherPriority.Loaded, new Action(() => LoadNotatkiAvatars()));
            }
        }

        private void BtnDodajNotatke_Click(object sender, RoutedEventArgs e)
        {
            if (aktualnyOdbiorcaID == 0 || string.IsNullOrWhiteSpace(txtNowaNotatka.Text)) return;

            // Tryb edycji
            if (edytowanaNotatkaId > 0)
            {
                ZapiszEdycjeNotatki(edytowanaNotatkaId, txtNowaNotatka.Text);
                edytowanaNotatkaId = 0;
                txtNowaNotatka.Text = "";
                btnDodajNotatke.Content = "Dodaj";
                return;
            }

            // Tryb dodawania
            try
            {
                string notatkaText = txtNowaNotatka.Text;
                using (var conn = new SqlConnection(connectionString))
                {
                    conn.Open();
                    var cmd = new SqlCommand("INSERT INTO NotatkiCRM (IDOdbiorcy, Tresc, KtoDodal) VALUES (@id, @tresc, @op)", conn);
                    cmd.Parameters.AddWithValue("@id", aktualnyOdbiorcaID);
                    cmd.Parameters.AddWithValue("@tresc", notatkaText);
                    cmd.Parameters.AddWithValue("@op", operatorID);
                    cmd.ExecuteNonQuery();
                }
                // Rejestruj dodanie notatki do licznika połączeń
                CallReminderService.Instance.LogCrmAction(operatorID, aktualnyOdbiorcaID, wasCalled: false, noteAdded: true, statusChanged: false);
                txtNowaNotatka.Text = "";
                WczytajNotatki(aktualnyOdbiorcaID);
                // Aktualizuj kolumnę OstatniNotatka w głównej liście bez przeładowywania
                AktualizujNotatkeLokalnie(aktualnyOdbiorcaID, notatkaText);
                ShowToast("Notatka dodana! 📝");
            }
            catch (Exception ex) { MessageBox.Show(ex.Message); }
        }

        private int edytowanaNotatkaId = 0;

        private void BtnEdytujNotatke_Click(object sender, RoutedEventArgs e)
        {
            if (sender is Button btn && btn.Tag is NotatkaCRM notatka)
            {
                edytowanaNotatkaId = notatka.Id;
                txtNowaNotatka.Text = notatka.Tresc;
                txtNowaNotatka.Focus();
                btnDodajNotatke.Content = "Zapisz";
            }
        }

        private void TxtNowaNotatka_KeyDown(object sender, System.Windows.Input.KeyEventArgs e)
        {
            if (e.Key == System.Windows.Input.Key.Enter)
            {
                e.Handled = true;
                BtnDodajNotatke_Click(btnDodajNotatke, new RoutedEventArgs());
            }
        }

        private void ZapiszEdycjeNotatki(int id, string nowyTekst)
        {
            try
            {
                // Dodaj znacznik "(edytowano)" jeśli jeszcze nie ma
                string tekstDoZapisu = nowyTekst.TrimEnd();
                if (!tekstDoZapisu.EndsWith("(edytowano)"))
                    tekstDoZapisu += " (edytowano)";

                using (var conn = new SqlConnection(connectionString))
                {
                    conn.Open();
                    var cmd = new SqlCommand("UPDATE NotatkiCRM SET Tresc = @tresc WHERE ID = @id", conn);
                    cmd.Parameters.AddWithValue("@tresc", tekstDoZapisu);
                    cmd.Parameters.AddWithValue("@id", id);
                    cmd.ExecuteNonQuery();
                }
                WczytajNotatki(aktualnyOdbiorcaID);
                ShowToast("Notatka zaktualizowana! ✏️");
            }
            catch (Exception ex) { MessageBox.Show(ex.Message); }
        }

        private void BtnUsunNotatke_Click(object sender, RoutedEventArgs e)
        {
            if (sender is Button btn && btn.Tag is NotatkaCRM notatka)
            {
                var result = MessageBox.Show("Czy na pewno chcesz usunąć tę notatkę?", "Potwierdzenie",
                    MessageBoxButton.YesNo, MessageBoxImage.Question);

                if (result == MessageBoxResult.Yes)
                {
                    try
                    {
                        using (var conn = new SqlConnection(connectionString))
                        {
                            conn.Open();
                            var cmd = new SqlCommand("DELETE FROM NotatkiCRM WHERE ID = @id", conn);
                            cmd.Parameters.AddWithValue("@id", notatka.Id);
                            cmd.ExecuteNonQuery();
                        }
                        WczytajNotatki(aktualnyOdbiorcaID);
                        ShowToast("Notatka usunięta! 🗑️");
                    }
                    catch (Exception ex) { MessageBox.Show(ex.Message); }
                }
            }
        }

        private void NotatkaText_Click(object sender, System.Windows.Input.MouseButtonEventArgs e)
        {
            if (sender is Grid grid && grid.Tag is NotatkaCRM notatka)
            {
                // Toggle rozwinięcia
                notatka.Rozwiniety = !notatka.Rozwiniety;

                // Odśwież listę
                var notatki = listaNotatek.ItemsSource as System.Collections.Generic.List<NotatkaCRM>;
                if (notatki != null)
                {
                    listaNotatek.ItemsSource = null;
                    listaNotatek.ItemsSource = notatki;
                }
            }
        }

        private void MenuTag_Click(object sender, RoutedEventArgs e)
        {
            if (dgKontakty.SelectedItem is DataRowView row && sender is MenuItem mi)
            {
                string tag = mi.Tag.ToString();
                string noweTagi = tag == "CLEAR" ? "" : tag;
                int id = (int)row["ID"];
                using (var conn = new SqlConnection(connectionString))
                {
                    conn.Open();
                    var cmd = new SqlCommand("UPDATE OdbiorcyCRM SET Tagi = @Tagi WHERE ID = @ID", conn);
                    cmd.Parameters.AddWithValue("@Tagi", noweTagi);
                    cmd.Parameters.AddWithValue("@ID", id);
                    cmd.ExecuteNonQuery();
                }
                WczytajDane(zachowajFiltry: true);
                ShowToast(tag == "CLEAR" ? "Usunięto tagi" : $"Oznaczono jako: {tag}");
            }
        }

        private async void ShowToast(string message)
        {
            if (toastPopup == null || toastText == null) return;
            toastText.Text = message;
            var fadeIn = new DoubleAnimation(0, 1, TimeSpan.FromSeconds(0.3));
            toastPopup.BeginAnimation(OpacityProperty, fadeIn);
            await Task.Delay(3000);
            var fadeOut = new DoubleAnimation(1, 0, TimeSpan.FromSeconds(0.3));
            toastPopup.BeginAnimation(OpacityProperty, fadeOut);
        }

        private void TxtSzukaj_TextChanged(object sender, TextChangedEventArgs e) => Filtruj();
        private void CmbStatus_SelectionChanged(object sender, SelectionChangedEventArgs e) => Filtruj();
        private void CmbWojewodztwo_SelectionChanged(object sender, SelectionChangedEventArgs e) => Filtruj();
        private void CmbBranza_SelectionChanged(object sender, SelectionChangedEventArgs e) => Filtruj();
        private void CmbHandlowiec_SelectionChanged(object sender, SelectionChangedEventArgs e) => Filtruj();

        private void Filtruj()
        {
            if (dtKontakty == null) return;
            string filter = "1=1";
            string txt = txtSzukaj.Text.Trim();
            if (!string.IsNullOrEmpty(txt))
            {
                txt = txt.Replace("'", "''");
                filter += $" AND (NAZWA LIKE '%{txt}%' OR MIASTO LIKE '%{txt}%' OR TELEFON_K LIKE '%{txt}%')";
            }
            if (cmbStatus.SelectedIndex > 0) filter += $" AND Status = '{(cmbStatus.SelectedItem as ComboBoxItem).Content}'";
            if (cmbWojewodztwo.SelectedIndex > 0) filter += $" AND Wojewodztwo = '{(cmbWojewodztwo.SelectedItem as ComboBoxItem).Content}'";
            // Skip separator (disabled item) in Branża filter
            if (cmbBranza.SelectedIndex > 0 && cmbBranza.SelectedItem is ComboBoxItem branzaItem && branzaItem.IsEnabled)
            {
                filter += $" AND PKD_Opis = '{branzaItem.Content}'";
            }

            // Filtr handlowca - pokazuj tylko wiersze gdzie ostatnią zmianę wykonał wybrany handlowiec
            if (cmbHandlowiec.SelectedIndex > 0)
            {
                string handlowiec = (cmbHandlowiec.SelectedItem as ComboBoxItem).Content.ToString().Replace("'", "''");
                filter += $" AND OstatniHandlowiec = '{handlowiec}'";
            }

            // Quick filter chips
            if (!string.IsNullOrEmpty(aktywnyChip))
            {
                if (aktywnyChip == "Zaległe")
                    filter += " AND DataNastepnegoKontaktu < #" + DateTime.Today.ToString("yyyy-MM-dd") + "#";
                else
                    filter += $" AND Tagi LIKE '%{aktywnyChip}%'";
            }

            dtKontakty.DefaultView.RowFilter = filter;
            if (txtLiczbaWynikow != null) txtLiczbaWynikow.Text = $"{dtKontakty.DefaultView.Count} klientów";
        }

        private void BtnKanban_Click(object sender, RoutedEventArgs e) { new KanbanWindow(connectionString, operatorID).Show(); }
        private void BtnDashboard_Click(object sender, RoutedEventArgs e) { new DashboardCRMWindow(connectionString).Show(); }
        private void BtnManager_Click(object sender, RoutedEventArgs e) { new PanelManageraWindow(connectionString).Show(); }
        private void BtnMapa_Click(object sender, RoutedEventArgs e) { new MapaCRMWindow(connectionString, operatorID).Show(); }
        private void BtnReminder_Click(object sender, RoutedEventArgs e)
        {
            var config = new Models.CallReminderConfig { UserID = operatorID };
            new CallReminderWindow(connectionString, operatorID, config).Show();
        }
        private void BtnDodaj_Click(object sender, RoutedEventArgs e)
        {
            var okno = new OfertaCenowa.DodajOdbiorceWindow(connectionString, operatorID);
            if (okno.ShowDialog() == true)
            {
                // Jeśli użytkownik wybrał "Tylko moi", włącz ten filtr
                if (okno.FiltrujTylkoMoje && chkTylkoMoje != null)
                {
                    chkTylkoMoje.IsChecked = true;
                }
                WczytajDane();
            }
        }
        private void BtnOdswiez_Click(object sender, RoutedEventArgs e) => WczytajDane();
        private void ChkTylkoMoje_Changed(object sender, RoutedEventArgs e) => WczytajDane();
        private void BtnAdmin_Click(object sender, RoutedEventArgs e)
        {
            new CallReminderAdminPanel().Show();
        }

        private void BtnImportFirm_Click(object sender, RoutedEventArgs e)
        {
            var importDialog = new Dialogs.ImportFirmDialog(connectionString, operatorID);
            if (importDialog.ShowDialog() == true)
            {
                WczytajDane();
            }
        }

        private string aktywnyChip = "";

        private void Chip_Click(object sender, MouseButtonEventArgs e)
        {
            if (sender is Border chip && chip.Tag != null)
            {
                string tag = chip.Tag.ToString();
                if (aktywnyChip == tag)
                {
                    // Odznacz chip
                    aktywnyChip = "";
                    chip.BorderThickness = new Thickness(0);
                    chip.BorderBrush = null;
                }
                else
                {
                    // Zresetuj poprzedni chip
                    ResetujChipsy();
                    aktywnyChip = tag;
                    chip.BorderThickness = new Thickness(2);
                    chip.BorderBrush = new SolidColorBrush((Color)ColorConverter.ConvertFromString("#0F172A"));
                }
                Filtruj();
            }
        }

        private void ChipZalegle_Click(object sender, MouseButtonEventArgs e)
        {
            if (sender is Border chip)
            {
                if (aktywnyChip == "Zaległe")
                {
                    aktywnyChip = "";
                    chip.BorderThickness = new Thickness(0);
                }
                else
                {
                    ResetujChipsy();
                    aktywnyChip = "Zaległe";
                    chip.BorderThickness = new Thickness(2);
                    chip.BorderBrush = new SolidColorBrush((Color)ColorConverter.ConvertFromString("#0F172A"));
                }
                Filtruj();
            }
        }

        private void ResetujChipsy()
        {
            chipVIP.BorderThickness = new Thickness(0);
            chipPilne.BorderThickness = new Thickness(0);
            chipPremium.BorderThickness = new Thickness(0);
            chipZalegle.BorderThickness = new Thickness(0);
        }

        private void BtnKlientZadzwon_Click(object sender, RoutedEventArgs e)
        {
            if (txtHeaderTelefon == null) return;
            string tel = txtHeaderTelefon.Text.Replace(" ", "").Replace("-", "");
            if (tel.Length > 0 && tel != "-")
            {
                Process.Start(new ProcessStartInfo($"tel:{tel}") { UseShellExecute = true });
                // Rejestruj połączenie do licznika
                if (aktualnyOdbiorcaID > 0)
                    CallReminderService.Instance.LogCrmAction(operatorID, aktualnyOdbiorcaID, wasCalled: true, noteAdded: false, statusChanged: false);
            }
        }

        private void BtnKlientEdytuj_Click(object sender, RoutedEventArgs e)
        {
            if (aktualnyOdbiorcaID == 0) return;
            if (new EdycjaKontaktuWindow { KlientID = aktualnyOdbiorcaID, OperatorID = operatorID }.ShowDialog() == true) WczytajDane(zachowajFiltry: true);
        }

        private void TxtKlientTelefon_Click(object sender, MouseButtonEventArgs e) => BtnKlientZadzwon_Click(sender, null);
        private void DgKontakty_MouseDoubleClick(object sender, MouseButtonEventArgs e) => BtnKlientEdytuj_Click(sender, null);
        private void MenuZadzwon_Click(object sender, RoutedEventArgs e) => BtnKlientZadzwon_Click(sender, null);
        private void MenuEdytuj_Click(object sender, RoutedEventArgs e) => BtnKlientEdytuj_Click(sender, null);

        private void MenuUstawDate_Click(object sender, RoutedEventArgs e)
        {
            if (aktualnyOdbiorcaID == 0 && dgKontakty.SelectedItem is DataRowView row) aktualnyOdbiorcaID = (int)row["ID"];
            if (aktualnyOdbiorcaID == 0) return;
            var dialog = new UstawDateKontaktuDialog(txtHeaderKlient.Text);
            if (dialog.ShowDialog() == true)
            {
                using (var conn = new SqlConnection(connectionString))
                {
                    conn.Open();
                    var cmd = new SqlCommand("UPDATE OdbiorcyCRM SET DataNastepnegoKontaktu = @Data WHERE ID = @ID", conn);
                    cmd.Parameters.AddWithValue("@Data", dialog.WybranaData.Value);
                    cmd.Parameters.AddWithValue("@ID", aktualnyOdbiorcaID);
                    cmd.ExecuteNonQuery();
                }
                // Aktualizuj lokalnie zamiast przeładowywać całą listę - widok nie będzie resetowany
                AktualizujDateLokalnie(aktualnyOdbiorcaID, dialog.WybranaData.Value);
                ShowToast($"Data kontaktu ustawiona: {dialog.WybranaData:dd.MM.yyyy}");
            }
        }

        private void MenuStatus_Click(object sender, RoutedEventArgs e)
        {
            if (e.OriginalSource is MenuItem mi && mi.Tag != null)
            {
                string nowyStatus = mi.Tag.ToString();
                int id = 0;
                if (dgKontakty.SelectedItem is DataRowView row) id = (int)row["ID"];
                if (id > 0)
                {
                    using (var conn = new SqlConnection(connectionString))
                    {
                        conn.Open();
                        var cmdUpdate = new SqlCommand("UPDATE OdbiorcyCRM SET Status = @Status WHERE ID = @ID", conn);
                        cmdUpdate.Parameters.AddWithValue("@Status", nowyStatus);
                        cmdUpdate.Parameters.AddWithValue("@ID", id);
                        cmdUpdate.ExecuteNonQuery();
                        var cmdLog = new SqlCommand("INSERT INTO HistoriaZmianCRM (IDOdbiorcy, TypZmiany, WartoscNowa, KtoWykonal, DataZmiany) VALUES (@id, 'Zmiana statusu', @val, @op, GETDATE())", conn);
                        cmdLog.Parameters.AddWithValue("@id", id);
                        cmdLog.Parameters.AddWithValue("@val", nowyStatus);
                        cmdLog.Parameters.AddWithValue("@op", operatorID);
                        cmdLog.ExecuteNonQuery();
                    }
                    // Rejestruj zmianę statusu do licznika połączeń
                    CallReminderService.Instance.LogCrmAction(operatorID, id, wasCalled: false, noteAdded: false, statusChanged: true, nowyStatus);
                    // Aktualizuj lokalnie zamiast przeładowywać całą listę - widok nie będzie resetowany
                    AktualizujStatusLokalnie(id, nowyStatus);
                    ShowToast("Zmieniono status na: " + nowyStatus);
                }
            }
        }

        private void MenuZmienStatus_Click(object sender, RoutedEventArgs e)
        {
            if (sender is MenuItem mi && mi.Tag != null)
            {
                string nowyStatus = mi.Tag.ToString();
                int id = 0;
                if (dgKontakty.SelectedItem is DataRowView row) id = (int)row["ID"];
                if (id > 0)
                {
                    using (var conn = new SqlConnection(connectionString))
                    {
                        conn.Open();
                        var cmdUpdate = new SqlCommand("UPDATE OdbiorcyCRM SET Status = @status WHERE ID = @id", conn);
                        cmdUpdate.Parameters.AddWithValue("@status", nowyStatus);
                        cmdUpdate.Parameters.AddWithValue("@id", id);
                        cmdUpdate.ExecuteNonQuery();

                        var cmdLog = new SqlCommand("INSERT INTO HistoriaZmianCRM (IDOdbiorcy, TypZmiany, WartoscNowa, KtoWykonal, DataZmiany) VALUES (@id, 'Zmiana statusu', @val, @op, GETDATE())", conn);
                        cmdLog.Parameters.AddWithValue("@id", id);
                        cmdLog.Parameters.AddWithValue("@val", nowyStatus);
                        cmdLog.Parameters.AddWithValue("@op", operatorID);
                        cmdLog.ExecuteNonQuery();
                    }
                    // Rejestruj zmianę statusu do licznika połączeń
                    CallReminderService.Instance.LogCrmAction(operatorID, id, wasCalled: false, noteAdded: false, statusChanged: true, nowyStatus);
                    // Aktualizuj lokalnie zamiast przeładowywać całą listę - widok nie będzie resetowany
                    AktualizujStatusLokalnie(id, nowyStatus);
                    ShowToast($"Status zmieniony na: {nowyStatus}");
                }
            }
        }

        private void MenuGoogle_Click(object sender, RoutedEventArgs e)
        {
            if (dgKontakty.SelectedItem is DataRowView row)
            {
                string nazwa = row["NAZWA"].ToString();
                string miasto = row["MIASTO"].ToString();
                string query = System.Net.WebUtility.UrlEncode($"{nazwa} {miasto}");
                Process.Start(new ProcessStartInfo($"https://www.google.com/search?q={query}") { UseShellExecute = true });
            }
        }

        private void MenuTrasa_Click(object sender, RoutedEventArgs e)
        {
            if (dgKontakty.SelectedItem is DataRowView row)
            {
                string adres = $"{row["ULICA"]}, {row["KOD"]} {row["MIASTO"]}";
                string query = System.Net.WebUtility.UrlEncode(adres);
                // Koziołki 40, 95-061 Dmosin jako punkt startowy (baza firmy)
                string origin = System.Net.WebUtility.UrlEncode("Koziołki 40, 95-061 Dmosin");
                Process.Start(new ProcessStartInfo($"https://www.google.com/maps/dir/{origin}/{query}") { UseShellExecute = true });
            }
        }

        private void MenuZmienLogo_Click(object sender, RoutedEventArgs e)
        {
            var dlg = new Microsoft.Win32.OpenFileDialog
            {
                Title = "Wybierz logo firmy",
                Filter = "Obrazy|*.png;*.jpg;*.jpeg;*.bmp;*.gif|Wszystkie pliki|*.*"
            };

            // Ustaw katalog początkowy tylko jeśli istnieje
            string networkPath = @"\\192.168.0.109\dane";
            try
            {
                if (System.IO.Directory.Exists(networkPath))
                    dlg.InitialDirectory = networkPath;
            }
            catch { }

            if (dlg.ShowDialog() == true)
            {
                try
                {
                    var bitmap = new System.Windows.Media.Imaging.BitmapImage();
                    bitmap.BeginInit();
                    bitmap.UriSource = new Uri(dlg.FileName);
                    bitmap.CacheOption = System.Windows.Media.Imaging.BitmapCacheOption.OnLoad;
                    bitmap.EndInit();
                    imgLogo.Source = bitmap;
                    txtLogoPlaceholder.Visibility = Visibility.Collapsed;

                    // Dostosuj rozmiar kontenera do proporcji obrazu
                    AdjustLogoContainerSize(bitmap.PixelWidth, bitmap.PixelHeight);

                    // Zapisz ścieżkę do pliku
                    SaveLogoPath(dlg.FileName);

                    ShowToast("Logo zostało zmienione");
                }
                catch (Exception ex)
                {
                    MessageBox.Show($"Nie udało się wczytać logo:\n{ex.Message}", "Błąd", MessageBoxButton.OK, MessageBoxImage.Error);
                }
            }
        }

        private void MenuUsunLogo_Click(object sender, RoutedEventArgs e)
        {
            imgLogo.Source = null;
            txtLogoPlaceholder.Visibility = Visibility.Visible;
            // Przywróć domyślny rozmiar
            borderLogo.Width = double.NaN;
            borderLogo.Height = double.NaN;

            // Usuń ścieżkę z pliku
            SaveLogoPath("");

            ShowToast("Logo zostało usunięte");
        }
        #endregion

        #region Theme Switching

        private void BtnToggleTheme_Click(object sender, RoutedEventArgs e)
        {
            CRMThemeService.Toggle();
            bool isLight = CRMThemeService.CurrentTheme == CRMThemeMode.Light;
            ApplyCRMTheme(isLight);
        }

        private void UpdateThemeButton(bool isLight)
        {
            if (btnToggleTheme != null)
                btnToggleTheme.Content = isLight ? "\U0001F319 Ciemny" : "\u2600\uFE0F Jasny";
        }

        private void ApplyCRMTheme(bool isLight)
        {
            UpdateThemeButton(isLight);

            if (isLight)
            {
                // ══════════════════════════════════════════════
                // LIGHT THEME - profesjonalny jasny z kontrastem
                // ══════════════════════════════════════════════

                // Tło okna: ciepły szary (NIE biały) daje kontrast
                mainWindow.Background = new SolidColorBrush(Color.FromRgb(241, 245, 249));  // #F1F5F9 slate-100

                // ── Tła: wyraźna hierarchia jasności ──
                Resources["BgPrimary"] = new SolidColorBrush(Color.FromRgb(241, 245, 249));    // #F1F5F9 główne tło
                Resources["BgSecondary"] = new SolidColorBrush(Color.FromRgb(255, 255, 255));   // #FFFFFF karty/panele
                Resources["BgTertiary"] = new SolidColorBrush(Color.FromRgb(226, 232, 240));    // #E2E8F0 zagnieżdżone
                Resources["BgElevated"] = new SolidColorBrush(Color.FromRgb(203, 213, 225));    // #CBD5E1 wyróżnione

                // ── Akcent: ciemny zielony dobrze widoczny na jasnym ──
                Resources["AccentPrimary"] = new SolidColorBrush(Color.FromRgb(21, 128, 61));   // #15803D green-700
                Resources["AccentLight"] = new SolidColorBrush(Color.FromRgb(34, 197, 94));     // #22C55E green-500
                Resources["AccentBg"] = new SolidColorBrush(Color.FromRgb(220, 252, 231));      // #DCFCE7 green-100

                // ── Tekst: ciemny na jasnym - wysoki kontrast ──
                Resources["TextPrimary"] = new SolidColorBrush(Color.FromRgb(15, 23, 42));      // #0F172A slate-900
                Resources["TextSecondary"] = new SolidColorBrush(Color.FromRgb(51, 65, 85));    // #334155 slate-700
                Resources["TextMuted"] = new SolidColorBrush(Color.FromRgb(100, 116, 139));     // #64748B slate-500

                // ── Bordy: widoczne szare linie ──
                Resources["BorderDefault"] = new SolidColorBrush(Color.FromRgb(203, 213, 225)); // #CBD5E1 slate-300
                Resources["BorderLight"] = new SolidColorBrush(Color.FromRgb(226, 232, 240));   // #E2E8F0 slate-200
                Resources["BorderAccent"] = new SolidColorBrush(Color.FromRgb(21, 128, 61));    // #15803D

                // ── Aliasy kompatybilności ──
                Resources["PrimaryColor"] = new SolidColorBrush(Color.FromRgb(21, 128, 61));
                Resources["PrimaryLight"] = new SolidColorBrush(Color.FromRgb(220, 252, 231));
                Resources["TextDark"] = new SolidColorBrush(Color.FromRgb(15, 23, 42));
                Resources["TextGray"] = new SolidColorBrush(Color.FromRgb(51, 65, 85));
                Resources["BorderColor"] = new SolidColorBrush(Color.FromRgb(203, 213, 225));

                // ── Statusy: jasne tła z ciemnymi tekstami ──
                Resources["StatusSuccessBg"] = new SolidColorBrush(Color.FromRgb(220, 252, 231));
                Resources["StatusWarningBg"] = new SolidColorBrush(Color.FromRgb(254, 243, 199));
                Resources["StatusInfoBg"] = new SolidColorBrush(Color.FromRgb(219, 234, 254));
                Resources["StatusDangerBg"] = new SolidColorBrush(Color.FromRgb(254, 226, 226));
                Resources["StatusNeutralBg"] = new SolidColorBrush(Color.FromRgb(226, 232, 240));
                Resources["StatusTealBg"] = new SolidColorBrush(Color.FromRgb(204, 251, 241));

                // ── DataGrid: biały z wyraźnymi liniami ──
                dgKontakty.Background = new SolidColorBrush(Color.FromRgb(255, 255, 255));
                dgKontakty.RowBackground = new SolidColorBrush(Color.FromRgb(255, 255, 255));
                dgKontakty.AlternatingRowBackground = new SolidColorBrush(Color.FromRgb(248, 250, 252)); // #F8FAFC
                dgKontakty.GridLinesVisibility = DataGridGridLinesVisibility.Horizontal;
                dgKontakty.HorizontalGridLinesBrush = new SolidColorBrush(Color.FromRgb(226, 232, 240));
                dgKontakty.BorderBrush = new SolidColorBrush(Color.FromRgb(203, 213, 225));
                dgKontakty.BorderThickness = new Thickness(1);

                // Nagłówek tabeli: szary gradient, ciemny tekst
                var headerStyle = new Style(typeof(DataGridColumnHeader));
                headerStyle.Setters.Add(new Setter(DataGridColumnHeader.BackgroundProperty,
                    new SolidColorBrush(Color.FromRgb(226, 232, 240))));  // #E2E8F0 widoczne tło
                headerStyle.Setters.Add(new Setter(DataGridColumnHeader.ForegroundProperty,
                    new SolidColorBrush(Color.FromRgb(30, 41, 59))));     // #1E293B ciemny tekst
                headerStyle.Setters.Add(new Setter(DataGridColumnHeader.PaddingProperty, new Thickness(12, 14, 12, 14)));
                headerStyle.Setters.Add(new Setter(DataGridColumnHeader.FontWeightProperty, FontWeights.SemiBold));
                headerStyle.Setters.Add(new Setter(DataGridColumnHeader.FontSizeProperty, 13.0));
                headerStyle.Setters.Add(new Setter(DataGridColumnHeader.BorderThicknessProperty, new Thickness(0, 0, 1, 2)));
                headerStyle.Setters.Add(new Setter(DataGridColumnHeader.BorderBrushProperty,
                    new SolidColorBrush(Color.FromRgb(203, 213, 225)))); // #CBD5E1
                headerStyle.Setters.Add(new Setter(DataGridColumnHeader.HorizontalContentAlignmentProperty, HorizontalAlignment.Center));
                dgKontakty.ColumnHeaderStyle = headerStyle;

                // Komórki
                var cellStyle = new Style(typeof(DataGridCell));
                cellStyle.Setters.Add(new Setter(DataGridCell.BorderThicknessProperty, new Thickness(0)));
                cellStyle.Setters.Add(new Setter(DataGridCell.FocusVisualStyleProperty, null));
                cellStyle.Setters.Add(new Setter(DataGridCell.PaddingProperty, new Thickness(8, 4, 8, 4)));
                cellStyle.Setters.Add(new Setter(DataGridCell.BackgroundProperty, Brushes.Transparent));
                cellStyle.Setters.Add(new Setter(DataGridCell.ForegroundProperty,
                    new SolidColorBrush(Color.FromRgb(15, 23, 42))));    // #0F172A
                dgKontakty.CellStyle = cellStyle;

                // Wiersze z hover i selekcją
                var rowStyle = new Style(typeof(DataGridRow));
                rowStyle.Setters.Add(new Setter(DataGridRow.HeightProperty, 60.0));
                rowStyle.Setters.Add(new Setter(DataGridRow.FontSizeProperty, 14.0));
                rowStyle.Setters.Add(new Setter(DataGridRow.BackgroundProperty, Brushes.White));
                rowStyle.Setters.Add(new Setter(DataGridRow.BorderThicknessProperty, new Thickness(0, 0, 0, 1)));
                rowStyle.Setters.Add(new Setter(DataGridRow.BorderBrushProperty,
                    new SolidColorBrush(Color.FromRgb(226, 232, 240))));  // #E2E8F0 visible line
                var hoverTrigger = new Trigger { Property = DataGridRow.IsMouseOverProperty, Value = true };
                hoverTrigger.Setters.Add(new Setter(DataGridRow.BackgroundProperty,
                    new SolidColorBrush(Color.FromRgb(219, 234, 254)))); // #DBEAFE blue-100 hover
                hoverTrigger.Setters.Add(new Setter(DataGridRow.BorderBrushProperty,
                    new SolidColorBrush(Color.FromRgb(147, 197, 253)))); // #93C5FD blue-300 border
                hoverTrigger.Setters.Add(new Setter(DataGridRow.BorderThicknessProperty, new Thickness(2)));
                rowStyle.Triggers.Add(hoverTrigger);
                var selectedTrigger = new Trigger { Property = DataGridRow.IsSelectedProperty, Value = true };
                selectedTrigger.Setters.Add(new Setter(DataGridRow.BackgroundProperty,
                    new SolidColorBrush(Color.FromRgb(191, 219, 254)))); // #BFDBFE blue-200 selected bg
                selectedTrigger.Setters.Add(new Setter(DataGridRow.ForegroundProperty,
                    new SolidColorBrush(Color.FromRgb(15, 23, 42))));    // dark text on blue
                selectedTrigger.Setters.Add(new Setter(DataGridRow.BorderBrushProperty,
                    new SolidColorBrush(Color.FromRgb(59, 130, 246))));  // #3B82F6 blue-500 border
                selectedTrigger.Setters.Add(new Setter(DataGridRow.BorderThicknessProperty, new Thickness(2)));
                rowStyle.Triggers.Add(selectedTrigger);
                dgKontakty.RowStyle = rowStyle;

                // Walk tree
                ApplyThemeToTree(this, true);
            }
            else
            {
                // ── DARK THEME: restore original ──
                mainWindow.Background = new SolidColorBrush(Color.FromRgb(15, 23, 42));

                Resources["BgPrimary"] = new SolidColorBrush(Color.FromRgb(15, 23, 42));
                Resources["BgSecondary"] = new SolidColorBrush(Color.FromRgb(30, 41, 59));
                Resources["BgTertiary"] = new SolidColorBrush(Color.FromRgb(51, 65, 85));
                Resources["BgElevated"] = new SolidColorBrush(Color.FromRgb(71, 85, 105));

                Resources["AccentPrimary"] = new SolidColorBrush(Color.FromRgb(99, 102, 241));
                Resources["AccentLight"] = new SolidColorBrush(Color.FromRgb(165, 180, 252));
                Resources["AccentBg"] = new SolidColorBrush(Color.FromRgb(49, 46, 129));

                Resources["TextPrimary"] = new SolidColorBrush(Color.FromRgb(226, 232, 240));
                Resources["TextSecondary"] = new SolidColorBrush(Color.FromRgb(148, 163, 184));
                Resources["TextMuted"] = new SolidColorBrush(Color.FromRgb(100, 116, 139));

                Resources["BorderDefault"] = new SolidColorBrush(Color.FromRgb(51, 65, 85));
                Resources["BorderLight"] = new SolidColorBrush(Color.FromRgb(71, 85, 105));
                Resources["BorderAccent"] = new SolidColorBrush(Color.FromRgb(99, 102, 241));

                Resources["PrimaryColor"] = new SolidColorBrush(Color.FromRgb(99, 102, 241));
                Resources["PrimaryLight"] = new SolidColorBrush(Color.FromRgb(49, 46, 129));
                Resources["TextDark"] = new SolidColorBrush(Color.FromRgb(226, 232, 240));
                Resources["TextGray"] = new SolidColorBrush(Color.FromRgb(148, 163, 184));
                Resources["BorderColor"] = new SolidColorBrush(Color.FromRgb(51, 65, 85));

                // Przywróć ciemne statusy
                Resources["StatusSuccessBg"] = new SolidColorBrush(Color.FromRgb(20, 83, 45));
                Resources["StatusWarningBg"] = new SolidColorBrush(Color.FromRgb(120, 53, 15));
                Resources["StatusInfoBg"] = new SolidColorBrush(Color.FromRgb(30, 58, 138));
                Resources["StatusDangerBg"] = new SolidColorBrush(Color.FromRgb(127, 29, 29));
                Resources["StatusNeutralBg"] = new SolidColorBrush(Color.FromRgb(55, 65, 81));
                Resources["StatusTealBg"] = new SolidColorBrush(Color.FromRgb(19, 78, 74));

                dgKontakty.Background = new SolidColorBrush(Color.FromRgb(30, 41, 59));
                dgKontakty.RowBackground = new SolidColorBrush(Color.FromRgb(30, 41, 59));
                dgKontakty.AlternatingRowBackground = new SolidColorBrush(Color.FromRgb(39, 53, 72));
                dgKontakty.GridLinesVisibility = DataGridGridLinesVisibility.None;
                dgKontakty.BorderThickness = new Thickness(0);

                // Restore dark DataGrid header style
                var headerStyleDk = new Style(typeof(DataGridColumnHeader));
                headerStyleDk.Setters.Add(new Setter(DataGridColumnHeader.BackgroundProperty, new SolidColorBrush(Color.FromRgb(15, 23, 42))));
                headerStyleDk.Setters.Add(new Setter(DataGridColumnHeader.ForegroundProperty, new SolidColorBrush(Color.FromRgb(148, 163, 184))));
                headerStyleDk.Setters.Add(new Setter(DataGridColumnHeader.PaddingProperty, new Thickness(12, 14, 12, 14)));
                headerStyleDk.Setters.Add(new Setter(DataGridColumnHeader.FontWeightProperty, FontWeights.SemiBold));
                headerStyleDk.Setters.Add(new Setter(DataGridColumnHeader.FontSizeProperty, 13.0));
                headerStyleDk.Setters.Add(new Setter(DataGridColumnHeader.BorderThicknessProperty, new Thickness(0, 0, 0, 2)));
                headerStyleDk.Setters.Add(new Setter(DataGridColumnHeader.BorderBrushProperty, new SolidColorBrush(Color.FromRgb(51, 65, 85))));
                headerStyleDk.Setters.Add(new Setter(DataGridColumnHeader.HorizontalContentAlignmentProperty, HorizontalAlignment.Center));
                dgKontakty.ColumnHeaderStyle = headerStyleDk;

                var cellStyleDk = new Style(typeof(DataGridCell));
                cellStyleDk.Setters.Add(new Setter(DataGridCell.BorderThicknessProperty, new Thickness(0)));
                cellStyleDk.Setters.Add(new Setter(DataGridCell.FocusVisualStyleProperty, null));
                cellStyleDk.Setters.Add(new Setter(DataGridCell.PaddingProperty, new Thickness(8, 4, 8, 4)));
                cellStyleDk.Setters.Add(new Setter(DataGridCell.BackgroundProperty, Brushes.Transparent));
                cellStyleDk.Setters.Add(new Setter(DataGridCell.ForegroundProperty, new SolidColorBrush(Color.FromRgb(226, 232, 240))));
                dgKontakty.CellStyle = cellStyleDk;

                var rowStyleDk = new Style(typeof(DataGridRow));
                rowStyleDk.Setters.Add(new Setter(DataGridRow.HeightProperty, 60.0));
                rowStyleDk.Setters.Add(new Setter(DataGridRow.FontSizeProperty, 14.0));
                rowStyleDk.Setters.Add(new Setter(DataGridRow.BackgroundProperty, new SolidColorBrush(Color.FromRgb(30, 41, 59))));
                rowStyleDk.Setters.Add(new Setter(DataGridRow.BorderThicknessProperty, new Thickness(0)));
                rowStyleDk.Setters.Add(new Setter(DataGridRow.BorderBrushProperty, Brushes.Transparent));
                var hoverDk = new Trigger { Property = DataGridRow.IsMouseOverProperty, Value = true };
                hoverDk.Setters.Add(new Setter(DataGridRow.BackgroundProperty, new SolidColorBrush(Color.FromRgb(51, 65, 85))));
                hoverDk.Setters.Add(new Setter(DataGridRow.BorderBrushProperty, new SolidColorBrush(Color.FromRgb(99, 102, 241))));
                hoverDk.Setters.Add(new Setter(DataGridRow.BorderThicknessProperty, new Thickness(2)));
                rowStyleDk.Triggers.Add(hoverDk);
                var selectedDk = new Trigger { Property = DataGridRow.IsSelectedProperty, Value = true };
                selectedDk.Setters.Add(new Setter(DataGridRow.BackgroundProperty, new SolidColorBrush(Color.FromArgb(40, 99, 102, 241))));
                selectedDk.Setters.Add(new Setter(DataGridRow.BorderBrushProperty, new SolidColorBrush(Color.FromRgb(129, 140, 248)))); // indigo-400
                selectedDk.Setters.Add(new Setter(DataGridRow.BorderThicknessProperty, new Thickness(2)));
                rowStyleDk.Triggers.Add(selectedDk);
                dgKontakty.RowStyle = rowStyleDk;

                ApplyThemeToTree(this, false);
            }
        }

        private void ApplyThemeToTree(DependencyObject root, bool isLight)
        {
            // ── Light palette — wysoki kontrast, czytelny czarny tekst ──
            var ltBlack = new SolidColorBrush(Color.FromRgb(10, 10, 10));           // prawie czarny
            var ltTextPrimary = new SolidColorBrush(Color.FromRgb(15, 23, 42));     // #0F172A
            var ltTextSecondary = new SolidColorBrush(Color.FromRgb(51, 65, 85));   // #334155
            var ltTextMuted = new SolidColorBrush(Color.FromRgb(71, 85, 105));      // #475569
            var ltBg = Color.FromRgb(255, 255, 255);
            var ltBgCard = Color.FromRgb(248, 250, 252);      // #F8FAFC
            var ltBgPanel = Color.FromRgb(241, 245, 249);     // #F1F5F9
            var ltBgNested = Color.FromRgb(226, 232, 240);    // #E2E8F0
            var ltBorder = Color.FromRgb(203, 213, 225);      // #CBD5E1

            // ── Dark palette (original) ──
            var dkBg = Color.FromRgb(30, 41, 59);
            var dkBgDeep = Color.FromRgb(15, 23, 42);
            var dkBorder = Color.FromRgb(51, 65, 85);
            var dkTextPrimary = new SolidColorBrush(Color.FromRgb(226, 232, 240));
            var dkTextSecondary = new SolidColorBrush(Color.FromRgb(148, 163, 184));
            var dkAccentLight = new SolidColorBrush(Color.FromRgb(165, 180, 252));

            for (int i = 0; i < VisualTreeHelper.GetChildrenCount(root); i++)
            {
                var child = VisualTreeHelper.GetChild(root, i);

                if (child is TextBlock tb)
                {
                    if (tb.Foreground is SolidColorBrush brush)
                    {
                        var c = brush.Color;
                        if (isLight)
                        {
                            // White/near-white → czarny
                            if (c.R > 220 && c.G > 220 && c.B > 220 && c.A > 200) tb.Foreground = ltBlack;
                            // #E2E8F0 → czarny
                            else if (c.R == 226 && c.G == 232 && c.B == 240) tb.Foreground = ltBlack;
                            // #94A3B8 → ciemny szary
                            else if (c.R == 148 && c.G == 163 && c.B == 184) tb.Foreground = ltTextSecondary;
                            // #64748B → muted
                            else if (c.R == 100 && c.G == 116 && c.B == 139) tb.Foreground = ltTextMuted;
                            // Semi-transparent white → proper dark text based on alpha
                            else if (c.R > 200 && c.G > 200 && c.B > 200 && c.A > 100 && c.A <= 230)
                                tb.Foreground = ltTextPrimary;
                            else if (c.R > 200 && c.G > 200 && c.B > 200 && c.A > 30 && c.A <= 100)
                                tb.Foreground = ltTextSecondary;
                            // Light grays 130-200 → muted
                            else if (c.R > 130 && c.G > 130 && c.B > 130 && c.R <= 220 && c.A > 100)
                                tb.Foreground = ltTextMuted;
                            // #A5B4FC indigo light → dark blue
                            else if (c.R == 165 && c.G == 180 && c.B == 252)
                                tb.Foreground = new SolidColorBrush(Color.FromRgb(55, 48, 163)); // #3730A3
                            // #6366F1 indigo → darker
                            else if (c.R == 99 && c.G == 102 && c.B == 241)
                                tb.Foreground = new SolidColorBrush(Color.FromRgb(67, 56, 202)); // #4338CA
                            // Green accent → darker green
                            else if (c.R == 34 && c.G == 197 && c.B == 94)
                                tb.Foreground = new SolidColorBrush(Color.FromRgb(21, 128, 61)); // #15803D
                        }
                        else
                        {
                            // Reverse: black/dark → white
                            if (c.R < 30 && c.G < 30 && c.B < 30 && c.A > 150) tb.Foreground = dkTextPrimary;
                            else if (c.R == 15 && c.G == 23 && c.B == 42) tb.Foreground = dkTextPrimary;
                            else if (c.R == 51 && c.G == 65 && c.B == 85) tb.Foreground = dkTextSecondary;
                            else if (c.R == 71 && c.G == 85 && c.B == 105) tb.Foreground = dkTextSecondary;
                            else if (c.R == 21 && c.G == 128 && c.B == 61) tb.Foreground = dkAccentLight;
                            else if (c.R == 37 && c.G == 99 && c.B == 235) tb.Foreground = dkAccentLight;
                            else if (c.R == 55 && c.G == 48 && c.B == 163) // #3730A3 → #A5B4FC
                                tb.Foreground = new SolidColorBrush(Color.FromRgb(165, 180, 252));
                            else if (c.R == 67 && c.G == 56 && c.B == 202) // #4338CA → #6366F1
                                tb.Foreground = new SolidColorBrush(Color.FromRgb(99, 102, 241));
                        }
                    }
                }
                else if (child is Border border)
                {
                    if (border.Background is SolidColorBrush bg)
                    {
                        var c = bg.Color;
                        if (isLight)
                        {
                            // #1E293B → white
                            if (c.R == 30 && c.G == 41 && c.B == 59) border.Background = new SolidColorBrush(ltBg);
                            // #0F172A → panel gray
                            else if (c.R == 15 && c.G == 23 && c.B == 42) border.Background = new SolidColorBrush(ltBgNested);
                            // #334155 → lighter
                            else if (c.R == 51 && c.G == 65 && c.B == 85) border.Background = new SolidColorBrush(ltBgPanel);
                            // #475569 → medium
                            else if (c.R == 71 && c.G == 85 && c.B == 105) border.Background = new SolidColorBrush(ltBgNested);
                            // #273548 → alt row
                            else if (c.R == 39 && c.G == 53 && c.B == 72) border.Background = new SolidColorBrush(ltBgCard);
                            // Semi-transparent → light solid
                            else if (c.A < 60 && c.A > 0 && c.R > 200) border.Background = new SolidColorBrush(ltBgPanel);
                        }
                        else
                        {
                            if (c.R == 255 && c.G == 255 && c.B == 255 && c.A > 200) border.Background = new SolidColorBrush(dkBg);
                            else if (c.R == 248 && c.G == 250 && c.B == 252) border.Background = new SolidColorBrush(Color.FromRgb(39, 53, 72));
                            else if (c.R == 241 && c.G == 245 && c.B == 249) border.Background = new SolidColorBrush(dkBg);
                            else if (c.R == 226 && c.G == 232 && c.B == 240) border.Background = new SolidColorBrush(dkBgDeep);
                            else if (c.R == 203 && c.G == 213 && c.B == 225) border.Background = new SolidColorBrush(Color.FromRgb(71, 85, 105));
                        }
                    }
                    if (border.BorderBrush is SolidColorBrush bb)
                    {
                        var c = bb.Color;
                        if (isLight)
                        {
                            if (c.R == 51 && c.G == 65 && c.B == 85) border.BorderBrush = new SolidColorBrush(ltBorder);
                            else if (c.R == 71 && c.G == 85 && c.B == 105) border.BorderBrush = new SolidColorBrush(ltBorder);
                            // Semi-transparent borders → solid
                            else if (c.A < 100 && c.R > 200) border.BorderBrush = new SolidColorBrush(ltBorder);
                        }
                        else
                        {
                            if (c.R == 203 && c.G == 213 && c.B == 225) border.BorderBrush = new SolidColorBrush(dkBorder);
                            else if (c.R == 226 && c.G == 232 && c.B == 240) border.BorderBrush = new SolidColorBrush(Color.FromRgb(71, 85, 105));
                        }
                    }
                }
                else if (child is TextBox textBox)
                {
                    if (isLight)
                    {
                        if (textBox.Foreground is SolidColorBrush tbBrush && tbBrush.Color.R > 180)
                            textBox.Foreground = ltBlack;
                        if (textBox.Background is SolidColorBrush txBg && txBg.Color.A == 0)
                        { /* transparent stays */ }
                        else if (textBox.Background is SolidColorBrush txBg2 && txBg2.Color.R < 60)
                            textBox.Background = new SolidColorBrush(ltBg);
                        if (textBox.CaretBrush is SolidColorBrush cb && cb.Color.R > 200)
                            textBox.CaretBrush = ltBlack;
                    }
                    else
                    {
                        textBox.Foreground = dkTextPrimary;
                        textBox.CaretBrush = dkTextPrimary;
                    }
                }

                ApplyThemeToTree(child, isLight);
            }
        }

        #endregion

        #region New Dialogs

        private void BtnDuplicates_Click(object sender, RoutedEventArgs e)
        {
            var dialog = new Dialogs.DuplicateDetectionDialog(connectionString);
            dialog.Owner = this;
            dialog.ShowDialog();
            WczytajDane(zachowajFiltry: true);
        }

        private void BtnEmailTemplate_Click(object sender, RoutedEventArgs e)
        {
            if (aktualnyOdbiorcaID <= 0)
            {
                ShowToast("Wybierz klienta z listy");
                return;
            }

            if (dgKontakty.SelectedItem is DataRowView row)
            {
                var dialog = new Dialogs.EmailTemplateDialog(connectionString, row, operatorID);
                dialog.Owner = this;
                if (dialog.ShowDialog() == true)
                {
                    ShowToast("Email wyslany!");
                }
            }
        }

        #endregion

        #region Quick Status Buttons

        private void BtnQuickStatus_Click(object sender, RoutedEventArgs e)
        {
            if (sender is Button btn && btn.Tag != null)
            {
                string nowyStatus = btn.Tag.ToString();
                if (aktualnyOdbiorcaID <= 0)
                {
                    ShowToast("Wybierz klienta z listy");
                    return;
                }

                try
                {
                    using (var conn = new SqlConnection(connectionString))
                    {
                        conn.Open();
                        var cmdUpdate = new SqlCommand("UPDATE OdbiorcyCRM SET Status = @status WHERE ID = @id", conn);
                        cmdUpdate.Parameters.AddWithValue("@status", nowyStatus);
                        cmdUpdate.Parameters.AddWithValue("@id", aktualnyOdbiorcaID);
                        cmdUpdate.ExecuteNonQuery();

                        var cmdLog = new SqlCommand("INSERT INTO HistoriaZmianCRM (IDOdbiorcy, TypZmiany, WartoscNowa, KtoWykonal, DataZmiany) VALUES (@id, 'Zmiana statusu', @val, @op, GETDATE())", conn);
                        cmdLog.Parameters.AddWithValue("@id", aktualnyOdbiorcaID);
                        cmdLog.Parameters.AddWithValue("@val", nowyStatus);
                        cmdLog.Parameters.AddWithValue("@op", operatorID);
                        cmdLog.ExecuteNonQuery();
                    }
                    // Rejestruj zmianę statusu do licznika połączeń
                    CallReminderService.Instance.LogCrmAction(operatorID, aktualnyOdbiorcaID, wasCalled: false, noteAdded: false, statusChanged: true, nowyStatus);
                    // Aktualizuj lokalnie zamiast przeładowywać całą listę - widok nie będzie resetowany
                    AktualizujStatusLokalnie(aktualnyOdbiorcaID, nowyStatus);
                    ShowToast($"Status: {nowyStatus}");
                }
                catch (Exception ex)
                {
                    MessageBox.Show($"Błąd zmiany statusu: {ex.Message}", "Błąd", MessageBoxButton.OK, MessageBoxImage.Error);
                }
            }
        }

        #endregion
    }

    public class NotatkaCRM
    {
        public int Id { get; set; }
        public string Tresc { get; set; }
        public DateTime DataUtworzenia { get; set; }
        public string Operator { get; set; }
        public string Typ { get; set; } = "📝";
        public bool CzyNotatka { get; set; } = true;
        public double MaxHeight { get; set; } = 40; // Domyślnie zwinięta
        public bool Rozwiniety { get; set; } = false;
    }

    public class PhoneFormatConverter : System.Windows.Data.IValueConverter
    {
        public object Convert(object value, Type targetType, object parameter, System.Globalization.CultureInfo culture)
        {
            if (value == null || value == DBNull.Value) return "";
            string phone = value.ToString().Trim();
            if (string.IsNullOrEmpty(phone)) return "";

            // Usuń wszystkie znaki oprócz cyfr i +
            string digits = new string(phone.Where(c => char.IsDigit(c) || c == '+').ToArray());

            // Formatuj w zależności od długości
            if (digits.StartsWith("+48") && digits.Length == 12)
            {
                // +48 XXX XXX XXX
                return $"+48 {digits.Substring(3, 3)} {digits.Substring(6, 3)} {digits.Substring(9, 3)}";
            }
            else if (digits.StartsWith("+") && digits.Length >= 10)
            {
                // Międzynarodowy: +XX XXX XXX XXX
                string countryCode = digits.Substring(0, digits.Length - 9);
                string rest = digits.Substring(digits.Length - 9);
                return $"{countryCode} {rest.Substring(0, 3)} {rest.Substring(3, 3)} {rest.Substring(6, 3)}";
            }
            else if (digits.Length == 9)
            {
                // Polski: XXX XXX XXX
                return $"{digits.Substring(0, 3)} {digits.Substring(3, 3)} {digits.Substring(6, 3)}";
            }
            else if (digits.Length == 11 && digits.StartsWith("48"))
            {
                // 48XXXXXXXXX -> +48 XXX XXX XXX
                return $"+48 {digits.Substring(2, 3)} {digits.Substring(5, 3)} {digits.Substring(8, 3)}";
            }

            // Fallback - zwróć oryginał
            return phone;
        }

        public object ConvertBack(object value, Type targetType, object parameter, System.Globalization.CultureInfo culture)
        {
            throw new NotImplementedException();
        }
    }

    /// <summary>
    /// Konwerter daty z polskim dniem tygodnia - format: "dd.MM.yyyy (Pn)"
    /// </summary>
    public class DateWithDayConverter : System.Windows.Data.IValueConverter
    {
        private static readonly string[] PolishDays = { "Nd", "Pn", "Wt", "Śr", "Cz", "Pt", "Sb" };

        public object Convert(object value, Type targetType, object parameter, System.Globalization.CultureInfo culture)
        {
            if (value == null || value == DBNull.Value) return "";

            if (value is DateTime dt)
            {
                string dayAbbrev = PolishDays[(int)dt.DayOfWeek];
                return $"{dt:dd.MM.yyyy} ({dayAbbrev})";
            }

            if (DateTime.TryParse(value.ToString(), out DateTime parsed))
            {
                string dayAbbrev = PolishDays[(int)parsed.DayOfWeek];
                return $"{parsed:dd.MM.yyyy} ({dayAbbrev})";
            }

            return value.ToString();
        }

        public object ConvertBack(object value, Type targetType, object parameter, System.Globalization.CultureInfo culture)
        {
            throw new NotImplementedException();
        }
    }

    /// <summary>
    /// Konwerter koloru medalu - złoty, srebrny, brązowy
    /// </summary>
    public class MedalColorConverter : System.Windows.Data.IValueConverter
    {
        public object Convert(object value, Type targetType, object parameter, System.Globalization.CultureInfo culture)
        {
            string medal = value?.ToString() ?? "";
            return medal switch
            {
                "🥇" or "1" => new SolidColorBrush(System.Windows.Media.Color.FromRgb(255, 215, 0)),   // Gold
                "🥈" or "2" => new SolidColorBrush(System.Windows.Media.Color.FromRgb(192, 192, 192)), // Silver
                "🥉" or "3" => new SolidColorBrush(System.Windows.Media.Color.FromRgb(205, 127, 50)),  // Bronze
                _ => new SolidColorBrush(System.Windows.Media.Color.FromRgb(148, 163, 184))           // Gray for others
            };
        }

        public object ConvertBack(object value, Type targetType, object parameter, System.Globalization.CultureInfo culture)
            => throw new NotImplementedException();
    }

    /// <summary>
    /// Konwerter tekstu medalu - zamienia emoji na numer
    /// </summary>
    public class MedalTextConverter : System.Windows.Data.IValueConverter
    {
        public object Convert(object value, Type targetType, object parameter, System.Globalization.CultureInfo culture)
        {
            string medal = value?.ToString() ?? "";
            return medal switch
            {
                "🥇" => "1",
                "🥈" => "2",
                "🥉" => "3",
                _ => medal.TrimEnd('.')
            };
        }

        public object ConvertBack(object value, Type targetType, object parameter, System.Globalization.CultureInfo culture)
            => throw new NotImplementedException();
    }

    /// <summary>
    /// Konwerter typu notatki - zamienia emoji na ścieżkę SVG
    /// </summary>
    public class NoteTypeToPathConverter : System.Windows.Data.IValueConverter
    {
        // Notatka/Wiadomość (📝) - envelope icon
        private const string MessagePath = "M20,4H4C2.9,4,2.01,4.9,2.01,6L2,18c0,1.1,0.9,2,2,2h16c1.1,0,2-0.9,2-2V6C22,4.9,21.1,4,20,4z M20,8l-8,5L4,8V6l8,5l8-5V8z";
        // Status (🔄) - sync/refresh arrow icon
        private const string StatusPath = "M12,4V1L8,5l4,4V6c3.31,0,6,2.69,6,6c0,1.01-0.25,1.97-0.7,2.8l1.46,1.46C19.54,15.03,20,13.57,20,12C20,7.58,16.42,4,12,4z M12,18c-3.31,0-6-2.69-6-6c0-1.01,0.25-1.97,0.7-2.8L5.24,7.74C4.46,8.97,4,10.43,4,12c0,4.42,3.58,8,8,8v3l4-4l-4-4V18z";

        public object Convert(object value, Type targetType, object parameter, System.Globalization.CultureInfo culture)
        {
            string typ = value?.ToString() ?? "";
            string pathData = typ.Contains("🔄") || typ.ToLower().Contains("status") ? StatusPath : MessagePath;
            return Geometry.Parse(pathData);
        }

        public object ConvertBack(object value, Type targetType, object parameter, System.Globalization.CultureInfo culture)
            => throw new NotImplementedException();
    }

    /// <summary>
    /// Konwerter walidacji danych - sprawdza kompletność danych kontaktu
    /// </summary>
    public class ValidationWarningConverter : System.Windows.Data.IMultiValueConverter
    {
        public object Convert(object[] values, Type targetType, object parameter, System.Globalization.CultureInfo culture)
        {
            if (values == null || values.Length < 3) return "";

            string telefon = values[0]?.ToString()?.Trim() ?? "";
            string email = values[1]?.ToString()?.Trim() ?? "";
            object ostatniaZmiana = values[2];

            var warnings = new List<string>();

            // Sprawdź telefon
            if (string.IsNullOrEmpty(telefon))
                warnings.Add("Brak telefonu");

            // Sprawdź email
            if (string.IsNullOrEmpty(email) || !email.Contains("@"))
                warnings.Add("Brak/nieprawidłowy email");

            // Sprawdź ostatni kontakt > 60 dni
            if (ostatniaZmiana != null && ostatniaZmiana != DBNull.Value)
            {
                if (DateTime.TryParse(ostatniaZmiana.ToString(), out DateTime dt))
                {
                    if ((DateTime.Now - dt).TotalDays > 60)
                        warnings.Add("Kontakt > 60 dni temu");
                }
            }

            return warnings.Count > 0 ? string.Join("\n", warnings) : "";
        }

        public object[] ConvertBack(object value, Type[] targetTypes, object parameter, System.Globalization.CultureInfo culture)
            => throw new NotImplementedException();
    }

    /// <summary>
    /// Konwerter widoczności ostrzeżenia walidacji
    /// </summary>
    public class ValidationWarningVisibilityConverter : System.Windows.Data.IMultiValueConverter
    {
        public object Convert(object[] values, Type targetType, object parameter, System.Globalization.CultureInfo culture)
        {
            if (values == null || values.Length < 3) return Visibility.Collapsed;

            string telefon = values[0]?.ToString()?.Trim() ?? "";
            string email = values[1]?.ToString()?.Trim() ?? "";
            object ostatniaZmiana = values[2];

            // Brak telefonu
            if (string.IsNullOrEmpty(telefon)) return Visibility.Visible;

            // Brak email
            if (string.IsNullOrEmpty(email) || !email.Contains("@")) return Visibility.Visible;

            // Stary kontakt
            if (ostatniaZmiana != null && ostatniaZmiana != DBNull.Value)
            {
                if (DateTime.TryParse(ostatniaZmiana.ToString(), out DateTime dt))
                {
                    if ((DateTime.Now - dt).TotalDays > 60)
                        return Visibility.Visible;
                }
            }

            return Visibility.Collapsed;
        }

        public object[] ConvertBack(object value, Type[] targetTypes, object parameter, System.Globalization.CultureInfo culture)
            => throw new NotImplementedException();
    }

    /// <summary>
    /// Konwerter avatara handlowca - pobiera avatar na podstawie nazwy operatora
    /// </summary>
    public class HandlowiecAvatarConverter : System.Windows.Data.IValueConverter
    {
        private static readonly Dictionary<string, BitmapSource> _avatarCache = new();
        private static readonly Dictionary<string, string> _nameToId = new();
        private static bool _isInitialized = false;
        private static readonly string _connectionString = "Server=192.168.0.109;Database=LibraNet;User Id=pronova;Password=pronova;TrustServerCertificate=True";

        [System.Runtime.InteropServices.DllImport("gdi32.dll")]
        private static extern bool DeleteObject(IntPtr hObject);

        private static void Initialize()
        {
            if (_isInitialized) return;
            _isInitialized = true;

            try
            {
                using var conn = new Microsoft.Data.SqlClient.SqlConnection(_connectionString);
                conn.Open();
                using var cmd = new Microsoft.Data.SqlClient.SqlCommand("SELECT ID, Name FROM operators WHERE Name IS NOT NULL", conn);
                using var reader = cmd.ExecuteReader();
                while (reader.Read())
                {
                    string id = reader["ID"].ToString();
                    string name = reader["Name"]?.ToString()?.Trim() ?? "";
                    if (!string.IsNullOrEmpty(name) && !_nameToId.ContainsKey(name))
                        _nameToId[name] = id;
                }
            }
            catch { }
        }

        public object Convert(object value, Type targetType, object parameter, System.Globalization.CultureInfo culture)
        {
            Initialize();

            string name = value?.ToString()?.Trim();
            if (string.IsNullOrWhiteSpace(name)) return null;

            // Sprawdź cache
            if (_avatarCache.TryGetValue(name, out var cached))
                return cached;

            BitmapSource source = null;
            try
            {
                // Znajdź ID po nazwie
                string userId = _nameToId.TryGetValue(name, out var id) ? id : name;

                System.Drawing.Image img = null;
                if (UserAvatarManager.HasAvatar(userId))
                    img = UserAvatarManager.GetAvatarRounded(userId, 28);
                if (img == null)
                    img = UserAvatarManager.GenerateDefaultAvatar(name, userId, 28);

                if (img != null)
                {
                    using (img)
                    using (var bmp = new System.Drawing.Bitmap(img))
                    {
                        var hBitmap = bmp.GetHbitmap();
                        try
                        {
                            source = System.Windows.Interop.Imaging.CreateBitmapSourceFromHBitmap(
                                hBitmap, IntPtr.Zero, System.Windows.Int32Rect.Empty,
                                BitmapSizeOptions.FromEmptyOptions());
                            source.Freeze();
                        }
                        finally { DeleteObject(hBitmap); }
                    }
                }
            }
            catch { }

            _avatarCache[name] = source;
            return source;
        }

        public object ConvertBack(object value, Type targetType, object parameter, System.Globalization.CultureInfo culture)
        {
            throw new NotImplementedException();
        }

        /// <summary>
        /// Czyści cache (wywoływane przy przeładowaniu danych)
        /// </summary>
        public static void ClearCache()
        {
            _avatarCache.Clear();
        }
    }
}